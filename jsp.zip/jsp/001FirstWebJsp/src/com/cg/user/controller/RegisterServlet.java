package com.cg.user.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.user.exception.MyUserException;
import com.cg.user.model.MyUser;
import com.cg.user.service.IUserService;
import com.cg.user.service.UserServiceImpl;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	IUserService userService;
	String forward="/index.jsp";
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);
		try {
			userService= new UserServiceImpl();
		} catch (MyUserException e) {
			e.printStackTrace();
		}
	}
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getParameter("action");
				
		try{
			if(action.equals("listUser")) {				
				forward="/listUser.jsp";
			}else if(action.equals("addUserForm")) {
				forward="/addUserForm.jsp";
			}else if(action.equals("addUser")) {
				forward="/listUser.jsp";
			}else if(action.equals("loginForm")) {
				forward="/login.jsp";
			}else if(action.equals("checkLogin")) {
				String username = request.getParameter("username");
				String password = request.getParameter("password");
				MyUser myUser= new MyUser(username, password);
				boolean status=userService.authenticateUser(myUser);
				if(status)
					forward="/login.jsp";
				else
					forward="/successUser.jsp";
			}
		
			
		}catch (Exception e) {
			forward="/errorPage.jsp";
		}
		/*
		// step 1: get the request
		String strUser = request.getParameter("username");
		String strPass = request.getParameter("password");
		// step 2: set the contentType of response
		response.setContentType("text/html");// default response type is text
		// step 3: obtain the Writer to write the response
		PrintWriter pw = response.getWriter();
		// step 4:authenticate user and dispatch related specific response to other component
		RequestDispatcher rd = null;
		
		//invoke the registerUserService to persist the user in the database
		response.sendRedirect("registerSuccess.jsp");
		//client side redirection
*/		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
