  drop table myusers1;
  create table myusers1 (
  userId number primary key,
  username varchar2(30)not  null,
  password varchar2(30)not  null);
  
  drop sequence myusers1_seq;
  create sequence myusers1_seq start with 1;
  
  insert into myusers1 values(myusers1_seq.nextval,'111','111');
  insert into myusers1 values(myusers1_seq.nextval,'admin','admin');
  insert into myusers1 values(myusers1_seq.nextval,'smita','smita');
  commit;