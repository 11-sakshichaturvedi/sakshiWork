package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Servlet1
 */
@WebServlet("/Servlet1")
public class Servlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		//step1 : get the request paramaters
		//step2 : set the response content type
		response.setContentType("text/html");
		//step3 : get the PrintWriter
		PrintWriter pw = response.getWriter();
		//step4 : write the response
		pw.println("<h1 style='color:blue'>Servlet2</h1>");
		//step5 : close the writer
		pw.close();
		//request dispatching
		RequestDispatcher rd = request.getRequestDispatcher("Servlet2");
		rd.include(request, response);
		//server side re-direction
		//obtain on request object
		//the request url remains same , not changed 
		//( it will be treated as same request)
		//although the final output is with the collaboration of other servlet
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
