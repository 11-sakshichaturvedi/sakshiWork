package com.cg.lab.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.lab.exceptions.EmployeeException;

public class JdbcUtility {
	private static Connection connection = null;
	

	public static Connection getConnection() throws EmployeeException {
		File file = null;
		FileInputStream inputStream = null;

		file = new File("resources/jdbc.properties");
		try {
			inputStream = new FileInputStream(file);
		} catch (FileNotFoundException e1) {
			throw new EmployeeException("File is not found");
		}

		Properties properties = new Properties();

		try {
			properties.load(inputStream);
			String driver = properties.getProperty("db.driver");
			String url = properties.getProperty("db.url");
			String username = properties.getProperty("db.user");
			String password = properties.getProperty("db.pass");

			Class.forName(driver);
			connection = DriverManager.getConnection(url, username, password);

		} catch (IOException e) {
			throw new EmployeeException("Unable to read file");
		} catch (ClassNotFoundException e) {
			throw new EmployeeException("Class is not found");
		} catch (SQLException e) {
			throw new EmployeeException("Connection is not created");
		}
		return connection;
	}
	public static void main(String[] args) throws EmployeeException {
		Connection con = JdbcUtility.getConnection();
		if(con!=null)
			System.out.println("Connection Obtained!!!");
		else
			System.out.println("Connection NOT Obtained!!!");
	}	
}















