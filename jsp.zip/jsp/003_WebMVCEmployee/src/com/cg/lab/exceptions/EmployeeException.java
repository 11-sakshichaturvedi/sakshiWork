package com.cg.lab.exceptions;

public class EmployeeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8382147563952015115L;

	public EmployeeException(String msg) {
		super(msg);
	}

}
