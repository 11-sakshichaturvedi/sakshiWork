/**
 * 
 */
package com.cg.servlet;
import java.io.IOException;

import javax.servlet.GenericServlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
/**
 * @author Smita
 *
 */
public class HelloServlet extends GenericServlet{
	//life cycle of the servlet
	//Servlet object initialization
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		System.out.println("~~~~~~~~init invoked __ Only once per servlet~~~~~~~~~~~~~~~~~~~~");
	}
	
	@Override
	public void service(ServletRequest req, ServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}
}
