package com.cg.user_project.user_project.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.user_project.connection.MyConnection;
import com.cg.user_project.model.User;
import com.cg.user_project.user_project.dao.IUserDao;
import com.cg.user_project.user_project.dao.UserDao;
import com.cg.user_project.user_project.exception.UserException;

public class UserService implements IUserService {
	private IUserDao userDao;

	public UserService() {
		userDao = new UserDao();
	}

	@Override
	public int checkUser(User user) throws UserException {

		return userDao.checkUser(user);
	}

	@Override
	public int addUser(User user) throws UserException {

		return userDao.addUser(user);
	}

	@Override
	public int deleteUser(String userId) throws UserException {

		return userDao.deleteUser(userId);
	}

	@Override
	public int updateUser(User user) throws UserException {

		return userDao.updateUser(user);
	}

	@Override
	public List<User> getAllUsers() throws UserException {

		return userDao.getAllUsers();
	}

	@Override
	public User getUserById(String userId) throws UserException {

		return userDao.getUserById(userId);
	}
}
