/**
 * 
 */
package com.cg.user_project.user_project.dao;

import java.util.List;

import com.cg.user_project.model.User;
import com.cg.user_project.user_project.exception.UserException;

/**
 * @author Smita
 *
 */
public interface IUserDao {

	int checkUser(User user)throws UserException;

	int addUser(User user)throws UserException;

	int deleteUser(String userId)throws UserException;

	int updateUser(User user)throws UserException;

	List<User> getAllUsers()throws UserException;

	User getUserById(String userId)throws UserException;

}
