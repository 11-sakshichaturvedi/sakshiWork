package com.cg.user_project.user_project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.user_project.connection.MyConnection;
import com.cg.user_project.model.User;
import com.cg.user_project.user_project.exception.UserException;

public class UserDao implements IUserDao {
	private Connection connection;

	public UserDao() {
		connection = MyConnection.getConnection();
	}

	@Override
	public int checkUser(User user)throws UserException {
		int result=0;
		try {
			PreparedStatement ps = connection.prepareStatement("select uname from myusers where uname = ?");
			ps.setString(1, user.getUname());
			ResultSet rs = ps.executeQuery();
			if (rs.next()) // found
			{
				result=updateUser(user);
			} else {
				result=addUser(user);
			}
		} catch (Exception ex) {
			throw new UserException("Error in UserService checkUser() -->" + ex.getMessage());
		}
		return result;
	}

	@Override
	public int addUser(User user) throws UserException{
		int result=0;
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(
					"insert into myusers(uname, password, email, " + "registeredon) values (?, ?, ?, ? )");
			// Parameters start with 1
			preparedStatement.setString(1, user.getUname());
			preparedStatement.setString(2, user.getPassword());
			preparedStatement.setString(3, user.getEmail());
			preparedStatement.setDate(4, new java.sql.Date(user.getRegisteredon().getTime()));
			result=preparedStatement.executeUpdate();

		} catch (SQLException e) {
			throw new UserException("Error in UserService addUser() -->" + e.getMessage());
		}
		return result;
	}

	@Override
	public int deleteUser(String userId) throws UserException{
		int result=0;
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("delete from myusers where uname=?");
			// Parameters start with 1
			preparedStatement.setString(1, userId);
			result=preparedStatement.executeUpdate();
		} catch (SQLException e) {
			throw new UserException("Error in UserService deleteUser() -->" + e.getMessage());
		}
		return result;
	}

	@Override
	public int updateUser(User user)throws UserException {
		int result=0;
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("update myusers set " + "password=?, email=?, registeredon=?" + "where uname=?");
			// Parameters start with 1
			System.out.println(new java.sql.Date(user.getRegisteredon().getTime()));
			preparedStatement.setString(1, user.getPassword());
			preparedStatement.setString(2, user.getEmail());
			preparedStatement.setDate(3, new java.sql.Date(user.getRegisteredon().getTime()));
			preparedStatement.setString(4, user.getUname());
			result=preparedStatement.executeUpdate();

		} catch (SQLException e) {
			throw new UserException("Error in UserService updateUser() -->" + e.getMessage());
		}
		return result;
	}

	@Override
	public List<User> getAllUsers()throws UserException {
		List<User> myusers = new ArrayList<User>();
		try {
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery("select * from myusers");
			while (rs.next()) {
				User user = new User();
				user.setUname(rs.getString("uname"));
				user.setPassword(rs.getString("password"));
				user.setEmail(rs.getString("email"));
				user.setRegisteredon(rs.getDate("registeredon"));
				myusers.add(user);
			}
		} catch (SQLException e) {
			throw new UserException("Error in UserService getAllUsers() -->" + e.getMessage());
		}
		return myusers;
	}

	@Override
	public User getUserById(String userId)throws UserException {
		User user = new User();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("select * from myusers where uname=?");
			preparedStatement.setString(1, userId);
			ResultSet rs = preparedStatement.executeQuery();
			if (rs.next()) {
				user.setUname(rs.getString("uname"));
				user.setPassword(rs.getString("password"));
				user.setEmail(rs.getString("email"));
				user.setRegisteredon(rs.getDate("registeredon"));
			}
		} catch (SQLException e) {
			throw new UserException("Error in UserService getUserById() -->" + e.getMessage());
		}

		return user;
	}
}
