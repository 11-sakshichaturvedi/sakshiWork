package com.cg.user_project.model;
import java.io.Serializable;
import java.util.Date;
public class User implements Serializable {
	private static final long serialVersionUID = 5919638952238261594L;
	private String uname, password, email;
	private Date registeredon;
	public User() {
		// TODO Auto-generated constructor stub
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getRegisteredon() {
		return registeredon;
	}
	public void setRegisteredon(Date registeredon) {
		this.registeredon = registeredon;
	}

}
