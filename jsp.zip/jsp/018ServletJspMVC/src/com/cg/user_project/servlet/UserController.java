package com.cg.user_project.servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.user_project.model.User;
import com.cg.user_project.user_project.dao.UserDao;
import com.cg.user_project.user_project.service.IUserService;
import com.cg.user_project.user_project.service.UserService;

public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static String INSERT_OR_EDIT = "/user.jsp";
	private static String LIST_USER = "/listUser.jsp";
	private static String ERROR_PAGE = "/errorPage.jsp";
	private IUserService userService;

	public UserController() {
		super();
		userService = new UserService();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String forward = "";
		String action = request.getParameter("action");
		RequestDispatcher view = null;
		try {
			if (action.equalsIgnoreCase("delete")) {
				String userId = request.getParameter("userId");
				userService.deleteUser(userId);
				forward = LIST_USER;
				request.setAttribute("users", userService.getAllUsers());
			} else if (action.equalsIgnoreCase("edit")) {
				forward = INSERT_OR_EDIT;
				String userId = request.getParameter("userId");
				User user = userService.getUserById(userId);
				request.setAttribute("user", user);
			} else if (action.equalsIgnoreCase("listUser")) {
				forward = LIST_USER;
				request.setAttribute("users", userService.getAllUsers());
			} else {
				forward = INSERT_OR_EDIT;
			}

			view = request.getRequestDispatcher(forward);
			view.forward(request, response);
		} catch (Exception e) {
			view = request.getRequestDispatcher(ERROR_PAGE 
					+ "?errorMsg=" + e.getMessage());
			view.forward(request, response);
		}
	}// end of doGet

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		User user = new User();
		user.setUname(request.getParameter("uname"));
		user.setPassword(request.getParameter("pass"));
		RequestDispatcher view = null;
		try {
			try {
				Date reg = new SimpleDateFormat("yyyy/MM/dd").parse(request.getParameter("dob"));
				System.out.println("rrrrrrrrrrr" + reg);
				user.setRegisteredon(reg);
			} catch (ParseException e) {
				view = request.getRequestDispatcher(ERROR_PAGE + "?errorMsg=" + e.getMessage());
				view.forward(request, response);
			}
			user.setEmail(request.getParameter("email"));
			String userid = request.getParameter("uname");
			// user.setUname(userid);
			userService.checkUser(user);//

			view = request.getRequestDispatcher(LIST_USER);
			request.setAttribute("users", userService.getAllUsers());
			view.forward(request, response);
		} catch (Exception e) {
			view = request.getRequestDispatcher(ERROR_PAGE + "?errorMsg=" + e.getMessage());
			view.forward(request, response);
		}
	}// end of doPost
}
