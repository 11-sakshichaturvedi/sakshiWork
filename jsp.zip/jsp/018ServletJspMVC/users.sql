drop table myusers;
create table myusers
(
	uname varchar(20) constraint users_pk primary key,
	password varchar(20) NOT NULL,
	email varchar(50) unique not NULL,
	registeredon date NULL
);
insert into myusers values('111','111','111@g.com','19-Dec-2015');
insert into myusers values('222','222','222@g.com','21-Dec-2015');

/*Create four packages in the src folder.

1>com.cg.user_project.servlet: contains the servlets
			(UserController.java)
2>com.cg.user_project.user_project: contains the logic for database operation
			(UserDao.java)
3>com.cg.user_project.model: contains the POJO (Plain Old Java Object).
			(User.java)
4>com.cg.user_project.connection: contains the class for initiating 
			database connection(MyConnection.java)
5>src/oracle.properties
6>keep ojdbc6.jar in WEB/INF/lib and add to build path
*/
