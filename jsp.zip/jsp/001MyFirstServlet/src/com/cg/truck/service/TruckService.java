/**
 * 
 */
package com.cg.truck.service;

import com.cg.truck.exception.TruckException;
import com.cg.truck.model.Truck;

/**
 * @author brije
 *
 */
public class TruckService implements ITruckService {

	@Override
	public Truck searchTruckById(int truckId) throws TruckException {
		// TODO Auto-generated method stub
		return new Truck(101,"Kolkata","Mumbai");
	}

}
