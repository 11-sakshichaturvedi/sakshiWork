/**
 * 
 */
package com.cg.truck.model;

/**
 * @author brije
 *
 */
public class Truck {
	private int truckId; private String origin;private String destination;
	public Truck() {
		// TODO Auto-generated constructor stub
	}
	public Truck(int truckId, String origin, String destination) {
		super();
		this.truckId = truckId;
		this.origin = origin;
		this.destination = destination;
	}
	@Override
	public String toString() {
		return "Truck [truckId=" + truckId + ", origin=" + origin + ", destination=" + destination + "]";
	}
}
