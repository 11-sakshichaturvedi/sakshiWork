package com.cg.truck.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.truck.exception.TruckException;
import com.cg.truck.model.Truck;
import com.cg.truck.service.ITruckService;
import com.cg.truck.service.TruckService;

/**
 * Servlet implementation class TruckServlet
 */
@WebServlet("/TruckServlet")
public class TruckServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       //prep work for Service Object
	ITruckService truckService ;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TruckServlet() {
    	 truckService = new TruckService();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		//get the request
		int truckId= Integer.parseInt(request.getParameter("truckId"));//getparameter method always returns String
		try {
			Truck truck = truckService.searchTruckById(truckId);
			getServletContext().setAttribute("truck", truck);
			// redirection- client side re-direction
			response.sendRedirect("showSearchedTruck.jsp");
		} catch (TruckException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
