package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class UrlServlet
 */
@WebServlet("/UrlServlet")
public class UrlServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username=request.getParameter("username");
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		pw.println("Hello ,"+username);
		//lets obtain the session
		HttpSession session =request.getSession();//true or false
		session.setAttribute("username", username);
		
		//lets create cookies
		Cookie userCookie = new Cookie("username", username);
		response.addCookie(userCookie);
		Cookie passCookie = new Cookie("password", "1234");
		response.addCookie(passCookie);
		//false will return null if session does not exists
		//true will return a new session if session does not exists
		pw.println("<hr>Your Session Id : ,"+session.getId());
		//now lets do url rewritting
		/*pw.println("<hr><a href='display.jsp?username="+username+"'>Visit Again!!</a>");*/
		pw.println("<hr><a href='display.jsp'>Visit Again!!</a>");
		pw.close();
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
