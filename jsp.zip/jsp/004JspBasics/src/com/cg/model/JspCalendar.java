/**
 * 
 */
package com.cg.model;

import java.time.LocalDate;

/**
 * @author brije
 *
 */
public class JspCalendar{
	private LocalDate clock;
	public JspCalendar() {
		// TODO Auto-generated constructor stub
	}

	public LocalDate getClock() {
		return LocalDate.now();
	}

	public void setClock(LocalDate clock) {
		this.clock = clock;
	}
	
}
