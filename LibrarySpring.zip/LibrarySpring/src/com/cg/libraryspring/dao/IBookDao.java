package com.cg.libraryspring.dao;

import java.util.List;

import com.cg.libraryspring.beans.Book;
import com.cg.libraryspring.beans.Users;

public interface IBookDao {
	public List<Book> getAllBook();
	public void addBook(Book book);
	public void deleteBook(int bookId);
	public Book searchBook(int id);
	public void updateBook(Book book);
	public Users authentUser(Users ut);
	}
