package com.cg.libraryspring.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.libraryspring.beans.Book;
import com.cg.libraryspring.beans.Users;


@Repository("dao")
public class BookDaoImp implements IBookDao {
	@PersistenceContext
	EntityManager entitymanager;
	@Override
	public List<Book> getAllBook() {
		// TODO Auto-generated method stub
		Query queryOne=entitymanager.createQuery("FROM Book");
        List<Book> allBook=queryOne.getResultList();		
		return allBook;
	}
	
	@Override
	public void addBook(Book book) {
		// TODO Auto-generated method stub
		entitymanager.persist(book);
		entitymanager.flush();
		//return pro.getProdId();
	}
	@Override
	public void deleteBook(int bookId) {
		// TODO Auto-generated method stub
		Query queryTwo=entitymanager.
				createQuery("DELETE FROM Book WHERE bookId=:bookId");
		queryTwo.setParameter("bookId",bookId);
		queryTwo.executeUpdate();
		
		
	}
	@Override
	public Book searchBook(int bookId) {
		System.out.println("in dao");
		// TODO Auto-generated method stub
		Book book1=new Book();
		System.out.println("after ");
		Query queryOne=entitymanager.createQuery("FROM Book");
		System.out.println("in query");
        List<Book> allBook=queryOne.getResultList();	
        System.out.println("in list");
		
		for (Book book : allBook) {
			System.out.println("in for");
			if(book.getBookId()==(bookId) ) {
				System.out.println("in if");
				book1=book;
				System.out.println("in obj");
				break;
			}
		}
		System.out.println("in return");
		return book1;
	}

	@Override
	public void updateBook(Book book) {
		// TODO Auto-generated method stub
		Query queryThree=entitymanager.createQuery("UPDATE Book SET bookName=:bname,author1=:ba1,author2=:ba2,publisher=:pub,yearofpublication=:ypb,availability=:avl WHERE bookId=:eid");
		queryThree.setParameter("bname",book.getBookName());
		queryThree.setParameter("ba1",book.getAuthor1());
		queryThree.setParameter("ba2",book.getAuthor2());
		
		queryThree.setParameter("pub",book.getPublisher());
		queryThree.setParameter("ypb",book.getYearofpublication());
		queryThree.setParameter("avl",book.getAvailability());
		queryThree.setParameter("eid",book.getBookId());
		queryThree.executeUpdate();
	}
	
	@Override
    public Users authentUser(Users ut) {
    TypedQuery<Users> query = entitymanager.createQuery("SELECT d FROM Users d", Users.class);
    List<Users> lis = query.getResultList();
    for (Users user : lis) {
    if (user.getUserId().equals(ut.getUserId()) && user.getPassword().equals(ut.getPassword())) {
        System.out.println("Validated");
    return user;
    }
    }
    return null;
    }
}
