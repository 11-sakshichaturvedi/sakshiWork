package com.cg.libraryspring.beans;
 
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
 
@Entity
@Table(name="UsersLIb1")
public class Users {
    @Id
    @Column(name="userId")
    Integer userId;
    @Column(name="Password")
    String password;
    public Integer getUserId() {
        return userId;
    }
    public void setUserId(Integer userId) {
        this.userId = userId;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public Users() {
        
    }
    public Users(Integer userId, String password) {
        super();
        this.userId = userId;
        this.password = password;
    }
    
    
}
 
