package com.cg.libraryspring.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@SequenceGenerator(name="seqq_Id", initialValue=2001, allocationSize=1)
@Table(name="bookkinventorysss")
public class Book {
	@Id
@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seqq_Id")

@Column(name="book_id")
private int  bookId;





public int getBookId() {
	return bookId;
}

public void setBookId(int bookId) {
	this.bookId = bookId;
}

public String getBookName() {
	return bookName;
}

public void setBookName(String bookName) {
	this.bookName = bookName;
}

public String getAuthor1() {
	return author1;
}

public void setAuthor1(String author1) {
	this.author1 = author1;
}

public String getAuthor2() {
	return author2;
}

public void setAuthor2(String author2) {
	this.author2 = author2;
}

public String getPublisher() {
	return publisher;
}

public void setPublisher(String publisher) {
	this.publisher = publisher;
}

public Date getYearofpublication() {
	return yearofpublication;
}

public void setYearofpublication(Date yearofpublication) {
	this.yearofpublication = yearofpublication;
}

public String getAvailability() {
	return availability;
}

public void setAvailability(String availability) {
	this.availability = availability;
}

@Column(name="book_name")
private String  bookName;
@Column(name="author1")
private String author1;     
@Column(name="author2")
private String author2 ;  
@Column(name="publisher")
private String publisher    ;      
@Column(name="yearofpublication")
private Date yearofpublication     ;        
@Column(name="availability")
private String availability;
public Book() {
	// TODO Auto-generated constructor stub
}

public Book(int bookid, String bookname, String author1, String author2,String publisher,Date yearofpublication,String availability) {
	super();
	this.bookId = bookid;
	this.bookName = bookname;
	this.author1 = author1;
	this.author2 = author2;
	this.publisher=publisher;
	this.yearofpublication=yearofpublication;
	this.availability=availability;
}
}
