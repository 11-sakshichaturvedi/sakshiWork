package com.cg.libraryspring.service;

import java.util.List;

import com.cg.libraryspring.beans.Book;
import com.cg.libraryspring.beans.Users;

public interface IBookService {
	public List<Book> getAllBook();
	public void addBook(Book emp);
	public void deleteBook(int bookId);
	public Book searchBook(int id);
	public void updateBook(Book book) ;
	public Users authentUser(Users ut);
}
