package com.cg.libraryspring.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.libraryspring.beans.Book;
import com.cg.libraryspring.beans.Users;
import com.cg.libraryspring.dao.IBookDao;








@Transactional
@Service("obj")
public class BookServiceImpl implements IBookService{
	@Autowired
	IBookDao dao;
	@Override
	public List<Book> getAllBook() {
		// TODO Auto-generated method stub
		return dao.getAllBook();
	}
	@Override
	public void addBook(Book book) {
		// TODO Auto-generated method stub
	  dao.addBook(book);
		
	}
	@Override
	public void deleteBook(int bookId) {
		// TODO Auto-generated method stub
		dao.deleteBook(bookId);
	}
	
	@Override
	public Book searchBook(int id) {
		// TODO Auto-generated method stub
		System.out.println("in servuce");
		return dao.searchBook(id);
	}
	@Override
	public void updateBook(Book book) {
		// TODO Auto-generated method stub
		dao.updateBook(book);
	}
	@Override
	public Users authentUser(Users ut) {
        // TODO Auto-generated method stub
        System.out.println("Service User");
        return dao.authentUser(ut);
    }
}
