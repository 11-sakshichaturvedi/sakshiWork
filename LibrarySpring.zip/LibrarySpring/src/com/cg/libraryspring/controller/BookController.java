package com.cg.libraryspring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.libraryspring.beans.Book;
import com.cg.libraryspring.beans.Users;
import com.cg.libraryspring.service.IBookService;




@RestController
public class BookController {
@Autowired
IBookService obj;
@RequestMapping(value ="/book/create/",consumes = MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json",method = RequestMethod.POST)
public List<Book>  createBook(@RequestBody Book book) {
	
	System.out.println("hiiii");
	System.out.println(book);
	obj.addBook(book);
	return obj.getAllBook();
}
@RequestMapping(value = "/book",method = RequestMethod.GET,headers="Accept=application/json")
public List<Book> getAllBook(Model model) {
	
	
	return obj.getAllBook();
	
}
@RequestMapping(value = "/book/delete/{id}",
headers="Accept=application/json",method = RequestMethod.DELETE)
public List<Book> deleteBook(@PathVariable("id") int id) {
System.out.println(id);
obj.deleteBook(id);
return obj.getAllBook();
}
@RequestMapping(value ="/book/search/{id}",headers="Accept=application/json",method = RequestMethod.GET)
public Book searchBook(@PathVariable("id") int id) {
	System.out.println("In search");
	return obj.searchBook(id);
}



@RequestMapping(value ="/book/update/",consumes = MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json",method = RequestMethod.PUT)
public List<Book> updateBook(@RequestBody Book book) {
	
	System.out.println("Update");
	System.out.println(book);
	obj.updateBook(book);
	return obj.getAllBook();
}
@RequestMapping(value ="/book/atunUser/",consumes = MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json",method = RequestMethod.POST)
public Users athentUser(@RequestBody Users ut) {
System.out.println(ut);
System.out.println("Controller");
System.out.println(obj.authentUser(ut));
return obj.authentUser(ut);
}
}
