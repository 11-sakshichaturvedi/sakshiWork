/**
 * 
 */
package com.cg.user.service;

import java.util.List;

import com.cg.user.dao.IUserDao;
import com.cg.user.dao.UserDaoImpl;
import com.cg.user.exception.MyUserException;
import com.cg.user.model.MyUser;


public class UserServiceImpl implements IUserService {
	// prep work : Dao
	private IUserDao userDao;

	public UserServiceImpl() throws MyUserException {
		userDao = new UserDaoImpl();
	}

	@Override
	public int addUser(MyUser myUser) throws MyUserException {
		
		return userDao.addUser(myUser);
	}

	@Override
	public List<MyUser> listAllUser() throws MyUserException {
		
		return userDao.listAllUser();
	}

	@Override
	public boolean authenticateUser(MyUser myUser) throws MyUserException {
		return userDao.authenticateUser(myUser);
	}
	
	/*public int deleteUser(String username) throws MyUserException{
		return userDao.deleteUser(username);
	}

	
	public int updateUser(MyUser myUser)throws MyUserException {
		return userDao.updateUser(myUser);
	}
	
	public MyUser getUserById(String userId)throws MyUserException {
		return userDao.getUserById(userId);
	}*/
}
