package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// step 1: get the request
		String strUser = request.getParameter("username");
		String strPass = request.getParameter("password");
		// step 2: set the contentType of response
		response.setContentType("text/html");// default response type is text
		// step 3: obtain the Writer to write the response
		PrintWriter pw = response.getWriter();
		// step 4:authenticate user and dispatch related specific response to other component
		RequestDispatcher rd = null;
		//Cookies
		//step 1: create the cookie by passing key and value in string format
		Cookie userCookie = new Cookie("cookieUser", strUser);
		Cookie loginTimeCookie = new Cookie("userLoginTime", 
				LocalDateTime.now().toString());
		//step 2: 
		response.addCookie(userCookie);
		response.addCookie(loginTimeCookie);
		//invoke the registerUserService to persist the user in the database
		response.sendRedirect("registerSuccess.jsp");
		//client side redirection
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
