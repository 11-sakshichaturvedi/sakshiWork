package com.cg.lms.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.lms.exceptions.LibraryManagementException;
public class DBConnection {
	private static Connection conn=null;
	public static Connection getConnection() throws LibraryManagementException  {
		if(conn==null){
		try{
		FileInputStream fis1=new FileInputStream("resources/Jdbc.properties");
        Properties pro1=new Properties();
        pro1.load(fis1);
        String driver=pro1.getProperty("driver");
        String dburl=pro1.getProperty("dbURL");
        String user=pro1.getProperty("username");
        String pwd=pro1.getProperty("password");
        Class.forName(driver);
        conn=DriverManager.getConnection(dburl,user,pwd);
        	//conn.commit();
           	}
		catch(FileNotFoundException fe){
         		throw new LibraryManagementException("Unable to find Properties file" +fe.getMessage());
         	}catch(ClassNotFoundException ce){
         		throw new LibraryManagementException("Driver class not found" +ce.getMessage());
         	}catch(IOException ie){
         		throw new LibraryManagementException("Problem occured while reading properties" +ie.getMessage());
         	}catch(SQLException se){
         		throw new LibraryManagementException("Problem Occured while obtaining Connection" +se.getMessage());
         	}
	}
		return conn; 
}
}
