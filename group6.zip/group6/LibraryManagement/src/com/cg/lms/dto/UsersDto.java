package com.cg.lms.dto;

public class UsersDto {

	private String user_Id;
	private String user_name;
	private String password;
	private String email_id;

	public String getLibrarian() {
		return librarian;
	}

	public void setLibrarian(String librarian) {
		this.librarian = librarian;
	}

	private String librarian;

	public String getUser_id() {
		return user_Id;
	}

	public void setUser_id(String user_id) {
		this.user_Id = user_id;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail_id() {
		return email_id;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

}
