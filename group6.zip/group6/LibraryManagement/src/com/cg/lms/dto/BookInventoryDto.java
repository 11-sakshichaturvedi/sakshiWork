package com.cg.lms.dto;

public class BookInventoryDto {
	private String book_Id;
	private String book_name;
	private String author1;
	private String author2;
	private String publisher;
	private String yearOfPublication;
	private String availabiity;

	public String getAvailabiity() {
		return availabiity;
	}

	public void setAvailabiity(String availabiity) {
		this.availabiity = availabiity;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public String getYearOfPublication() {
		return yearOfPublication;
	}

	public void setYearOfPublication(String yearOfPublication) {
		this.yearOfPublication = yearOfPublication;
	}

	public String getBook_id() {
		return book_Id;
	}

	public void setBook_id(String book_id) {
		this.book_Id = book_id;
	}

	public String getBook_name() {
		return book_name;
	}

	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}

	public String getAuthor1() {
		return author1;
	}

	public void setAuthor1(String author1) {
		this.author1 = author1;
	}

	public String getAuthor2() {
		return author2;
	}

	public void setAuthor2(String author2) {
		this.author2 = author2;
	}

}
