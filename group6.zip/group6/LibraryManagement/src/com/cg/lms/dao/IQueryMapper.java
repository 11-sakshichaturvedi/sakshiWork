package com.cg.lms.dao;

public interface IQueryMapper {
	public static final String INSERT_QUERY = "INSERT into USERSLib values(?,?,?,?,?)";
	public static final String Login_QUERY = "select librarian from  USERSLib where User_id =? AND password =?";
	public static final String display_QUERY = "select user_id,password,librarian from  USERSLib";
	public static final String INSERT_Inventory = "INSERT INTO BOOKINVENTORY values(?,?,?,?,?,?,?)";
	public static final String display_Inventory = "select * from BOOKINVENTORY";
	public static final String DELETE_Records = "Delete from BOOKINVENTORY where book_id =?";
	public static final String DELETE_Request = "Delete from BOOKSREGISTRATION where REGISTRATION_ID =?";
	public static final String INSERT_request = "INSERT into BOOKSREGISTRATION values(seqreq.nextval,?,?,sysdate,?)";
	public static final String DeleteTransaction = "Delete from bookstransaction where TRANSACTION_ID=?";
	public static final String GET_RID = "SELECT seqreq.currval from dual";
	public static final String selectlib = "select librarian from USERSLib where user_id=?";
	public static final String See_Req = "select * from BOOKSREGISTRATION order by REGISTRATION_DATE";
	public static final String INSERT_transaction = "INSERT into bookstransaction  values(seqTID.nextval,?,?,?,?,?)";
	public static final String getEmail = "select EMAIL_ID from USERSLib";
	public static final String GET_TID = "SELECT seqTID.currval from dual";
	public static final String update_actualDate = "update bookstransaction set actualreturn_date=sysdate where transaction_id =?";
	public static final String update_fine = " update bookstransaction set fine=case when (Actualreturn_date-return_date)>0 then (actualreturn_date-return_date)+1 else 0 end where transaction_id=?";
	public static final String GET_RegId = "select REGISTRATION_ID from BOOKSREGISTRATION";
	public static final String GetBookId = "select BOOK_ID from BOOKINVENTORY";
	public static final String Get_transac = "select TRANSACTION_ID from bookstransaction";
	public static final String Search_query = "select * from bookstransaction where TRANSACTION_ID=?";
	public static final String updateStatusReq = "update BOOKSREGISTRATION set STATUS='issued' where REGISTRATION_ID=?";
	public static final String updateAvailability = "update BOOKINVENTORY set Availability='NA' where book_id=?";
	public static final String BookIdfromReg = "select Book_Id from BOOKSREGISTRATION where REGISTRATION_ID=?";
	public static final String selectAvailability = "select Availability from BOOKINVENTORY where book_id=?";
	public static final String selectIssueStatus = "select status from BOOKSREGISTRATION where REGISTRATION_ID=?";
	public static final String selectregTra = "select REGISTRATION_ID from bookstransaction where transaction_id=?";
	public static final String updateAvailabilityA = "update BOOKINVENTORY set Availability='A' where book_id=?";
	public static final String bookIdregtable = "select Book_Id from BOOKSREGISTRATION";
	public static final String userId = "select USER_ID from USERSLib";
}
