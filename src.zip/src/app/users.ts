export class Users{
    userId:Number;
    password:String;
}