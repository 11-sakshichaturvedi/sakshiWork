export class Book{
    bookId:number;
    bookName:string;
    author1:string;
    author2:string;
    publisher:string;
    yearofpublication:Date;
    availability:string;
    
}