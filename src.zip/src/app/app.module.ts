import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import {HttpModule} from '@angular/http';
import { FormsModule } from '@angular/forms';
import {Routes,RouterModule} from '@angular/router';
import { AddBookComponent } from './app.addBookcomponent';
import { ShowComponent } from './app.showBookcomponent';
import { DeleteBookComponent } from './app.deleteBookcomponent';
import { SearchUpdate } from './app.searchupdatecomponent';
import { LoginComponent } from './app.logincomponent';
import { HomeComponent } from './app.homecomponent';
const appRouter:Routes=[
{ path: "", redirectTo: 'home', pathMatch: 'full' },
{ path: 'loginpage', component: LoginComponent },
{path:'home/add',component:AddBookComponent},
{path:'home/loginpage',component:LoginComponent},
{path:'home/add/loginpage',component:LoginComponent},
{path:'home/delete/loginpage',component:LoginComponent},
{path:'home/search/loginpage',component:LoginComponent},
{path:'home/show/loginpage',component:LoginComponent},
{path:'home/show',component:ShowComponent},
{path:'home/delete',component:DeleteBookComponent},
{path:'home/search',component:SearchUpdate},
{path:'home/loginpage',component:LoginComponent},
{path:'home',component:HomeComponent},


];
@NgModule({
  imports:      [ BrowserModule,FormsModule,HttpModule,RouterModule.forRoot(appRouter)],
  declarations: [ AppComponent,AddBookComponent,ShowComponent,DeleteBookComponent,SearchUpdate,HomeComponent,LoginComponent],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
