"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var app_component_1 = require("./app.component");
var http_1 = require("@angular/http");
var forms_1 = require("@angular/forms");
var router_1 = require("@angular/router");
var app_addBookcomponent_1 = require("./app.addBookcomponent");
var app_showBookcomponent_1 = require("./app.showBookcomponent");
var app_deleteBookcomponent_1 = require("./app.deleteBookcomponent");
var app_searchupdatecomponent_1 = require("./app.searchupdatecomponent");
var app_logincomponent_1 = require("./app.logincomponent");
var app_homecomponent_1 = require("./app.homecomponent");
var appRouter = [
    { path: "", redirectTo: 'home', pathMatch: 'full' },
    { path: 'loginpage', component: app_logincomponent_1.LoginComponent },
    { path: 'home/add', component: app_addBookcomponent_1.AddBookComponent },
    { path: 'home/loginpage', component: app_logincomponent_1.LoginComponent },
    { path: 'home/add/loginpage', component: app_logincomponent_1.LoginComponent },
    { path: 'home/delete/loginpage', component: app_logincomponent_1.LoginComponent },
    { path: 'home/search/loginpage', component: app_logincomponent_1.LoginComponent },
    { path: 'home/show/loginpage', component: app_logincomponent_1.LoginComponent },
    { path: 'home/show', component: app_showBookcomponent_1.ShowComponent },
    { path: 'home/delete', component: app_deleteBookcomponent_1.DeleteBookComponent },
    { path: 'home/search', component: app_searchupdatecomponent_1.SearchUpdate },
    { path: 'home/loginpage', component: app_logincomponent_1.LoginComponent },
    { path: 'home', component: app_homecomponent_1.HomeComponent },
];
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [platform_browser_1.BrowserModule, forms_1.FormsModule, http_1.HttpModule, router_1.RouterModule.forRoot(appRouter)],
        declarations: [app_component_1.AppComponent, app_addBookcomponent_1.AddBookComponent, app_showBookcomponent_1.ShowComponent, app_deleteBookcomponent_1.DeleteBookComponent, app_searchupdatecomponent_1.SearchUpdate, app_homecomponent_1.HomeComponent, app_logincomponent_1.LoginComponent],
        bootstrap: [app_component_1.AppComponent]
    })
], AppModule);
exports.AppModule = AppModule;
