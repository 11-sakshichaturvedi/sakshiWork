import {Component, OnInit} from '@angular/core';
import {DatePipe} from '@angular/common';
import { BookService } from './book.service';
import { Book } from './book';
@Component({
    selector:'show-comp',
    templateUrl:'./app.showBook.html',
    providers:[BookService,DatePipe]
})
export class ShowComponent implements OnInit{
    book:Book[];
    statusmessage:string;


constructor(private bookservice:BookService,public datepipe:DatePipe) {}
ngOnInit(): void {
    this.bookservice.getAllBook().subscribe((bookData)=>this.book=bookData,
    (error)=>{
        this.statusmessage="Problem with service check server"
           // console.error(error);
    }    
    );
 
}
sortByBookId():void{
    //collegeId coloumn in clgData array of any type is sorted
    this.book.sort((ids, idl) => ids.bookId < idl.bookId ? -1 : ids.bookId > idl.bookId ? 1 : 0);
    console.log("mehod called");
}


 
}