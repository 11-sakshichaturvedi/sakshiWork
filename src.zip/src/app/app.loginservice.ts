

import { Injectable } from '@angular/core';
import {Users} from './users';
import {Http,Response,Headers, RequestOptions} from '@angular/http';
import { Observable } from 'rxjs/Observable';
import "rxjs/add/operator/map"
import "rxjs/add/operator/catch"
import { INVALID } from '../../node_modules/@angular/forms/src/model';
//import "rxjs/add/operator/throw"
@Injectable()
export class LoginService{
   
    constructor(private http:Http) {}
  




    loginAuthn(data:Users):Observable<Users>{

        let logData=JSON.stringify(data);
        
        alert(logData);
        
        let cpHeaders = new Headers({ 'Content-Type':
        'application/json' });
        
        let options = new RequestOptions({ headers: cpHeaders
        });
        
        
        return this.http
        
        .post('http://localhost:8082/LibrarySpring/rest/book/atunUser/',logData,options)
        
        .map((response:Response)=><Users>response.json())
        
        .catch(this.handleErrorSearch);
        
        }
        
        handleErrorSearch(error: Response){
        
        //console.error(error);
        alert("Invalid Credentials");
        return Observable.throw(error);
        
        }
}