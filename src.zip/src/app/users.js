"use strict";
var Users = (function () {
    function Users() {
    }
    return Users;
}());
exports.Users = Users;
