import {Component, OnInit} from '@angular/core';
import {Book} from "./book";
import {Router} from '@angular/router';
import { NgForm } from "@angular/Forms/forms";
import { BookService } from "./book.service";
@Component({
    selector:'add-comp',
    templateUrl:'./app.addBook.html',
    providers:[BookService]
})
export class AddBookComponent implements OnInit{
book:Book[];
//book1:Book={
   bookId:null;
   bookName:null;
   author1:null;
   author2:null;
   publisher:null;
   yearofpublication:null;
   availability:null;
//}
statusmessage:string;
constructor(private bookservice:BookService,private router:Router) {}
    
    
    model:any={};
    ngOnInit(){
        //this.empname=this.ac.snapshot.params['name'];
        //this.salary=this.ac.snapshot.params['name'];
        }
addData():void{
    this.bookservice.addBook(this.model).subscribe((bookData)=>this.book=bookData,
            (error)=>{
                this.statusmessage="Problem with service check server"
                   // console.error(error);
            }    
            );
    //Navigate from HomeComponent to EmployeeList
    this.router.navigate(['/show']);
}
getData(bookForm:NgForm):void{
    console.log(bookForm.value);

}}