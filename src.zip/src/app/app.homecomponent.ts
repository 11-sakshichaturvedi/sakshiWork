import { Component } from '@angular/core';

@Component({
  selector: 'home-comp',
  templateUrl: './app.homecomponent.html',
   styleUrls: ['./app.component.css']
})
export class HomeComponent { name = 'Welcome  Angular 2 In Cg'; }
