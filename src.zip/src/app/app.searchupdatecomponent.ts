import {Component} from '@angular/core';
import {Book} from './book';
import {Router} from '@angular/router';
import {NgForm} from "@angular/Forms/forms";
import { BookService } from './book.service';
import {DatePipe} from '@angular/common';
@Component({
 selector: 'search-app',
  templateUrl:'./app.searchupdate.html',
  providers:[BookService,DatePipe]
  
})
export class SearchUpdate{

   
    constructor(private bookservice:BookService,private router:Router,public datepipe:DatePipe) {}
    book:Book[];
    statusmessage:string;
    msg:boolean=false;
    //employees:Employee[];
    model:any={};
    bookId:number;
  //  ngOnInit(){
        //this.empname=this.ac.snapshot.params['name'];
        //this.salary=this.ac.snapshot.params['name'];
       // }
    
searchData():void{
    this.bookservice.searchBookId(this.bookId).subscribe((bookData)=>this.model=bookData,
            (error)=>{
                this.statusmessage="Problem with service check server"
                   // console.error(error);
            }    
            );
    this.msg=true;
    console.log(this.bookId);
}
updateBook():void{
    this.bookservice.updateBook(this.model).subscribe((bookData)=>this.model=bookData,
            (error)=>{
                this.statusmessage="Problem with service check server"
                this.statusmessage="no such value found"
                   // console.error(error);
            }  
            
            );
  //Navigate from EmployeeSearchComponent to EmployeeList
    this.router.navigate(['/show']);
}


getData(bookForm:NgForm):void{
    console.log(bookForm.value);

}
}