"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var book_service_1 = require("./book.service");
var common_1 = require("@angular/common");
var SearchUpdate = (function () {
    function SearchUpdate(bookservice, router, datepipe) {
        this.bookservice = bookservice;
        this.router = router;
        this.datepipe = datepipe;
        this.msg = false;
        //employees:Employee[];
        this.model = {};
    }
    //  ngOnInit(){
    //this.empname=this.ac.snapshot.params['name'];
    //this.salary=this.ac.snapshot.params['name'];
    // }
    SearchUpdate.prototype.searchData = function () {
        var _this = this;
        this.bookservice.searchBookId(this.bookId).subscribe(function (bookData) { return _this.model = bookData; }, function (error) {
            _this.statusmessage = "Problem with service check server";
            // console.error(error);
        });
        this.msg = true;
        console.log(this.bookId);
    };
    SearchUpdate.prototype.updateBook = function () {
        var _this = this;
        this.bookservice.updateBook(this.model).subscribe(function (bookData) { return _this.model = bookData; }, function (error) {
            _this.statusmessage = "Problem with service check server";
            _this.statusmessage = "no such value found";
            // console.error(error);
        });
        //Navigate from EmployeeSearchComponent to EmployeeList
        this.router.navigate(['/show']);
    };
    SearchUpdate.prototype.getData = function (bookForm) {
        console.log(bookForm.value);
    };
    return SearchUpdate;
}());
SearchUpdate = __decorate([
    core_1.Component({
        selector: 'search-app',
        templateUrl: './app.searchupdate.html',
        providers: [book_service_1.BookService, common_1.DatePipe]
    }),
    __metadata("design:paramtypes", [book_service_1.BookService, router_1.Router, common_1.DatePipe])
], SearchUpdate);
exports.SearchUpdate = SearchUpdate;
