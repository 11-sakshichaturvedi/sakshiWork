import {Component} from '@angular/core';
import {Book} from './book';
import {Router} from '@angular/router';
import {NgForm} from "@angular/Forms/forms";
import { BookService } from './book.service';
import { LoginService } from './app.loginservice';
import { INVALID } from '../../node_modules/@angular/forms/src/model';
@Component({
 selector: 'login-comp',
  templateUrl:'./app.login.html',
  providers:[LoginService]
  
})
export class LoginComponent{

   
    constructor(private loginservice:LoginService,private router:Router) {}
    book:Book[];
    statusmessage:string;
    msg:boolean=false;
    //employees:Employee[];
    model:any={};
   status:boolean=true;
    loginAuthen(): void {
    this.status=false;
    this.loginservice.loginAuthn(this.model).subscribe((valid)=>{if(valid!=null){
    console.log(valid);
    this.router.navigate(['/home']);
    }
    else{
        
    }
    
    } );
    
}}