package com.capgemini.mobilepurchase.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import junit.framework.Assert;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.mobilepurchase.dto.MobilePurchaseSystemCustomer;
import com.capgemini.mobilepurchase.exceptions.MobilePurchaseException;

public class MobilePurchaseSystemDaoTest {
	static MobilePurchaseSystemCustomer dtoObj;
	static MobilePurchaseDaoImp mpDao;
	@BeforeClass
	public static void setuptest1() 
	{
	mpDao= new MobilePurchaseDaoImp();
	}

	@AfterClass
	public static void setuptest2() 
	{
	mpDao= null;
	}
	@After
	public  void setuptest3() 
	{
	dtoObj= null;
	}
	@Before
	public  void setUPtest() throws Exception
	{
	dtoObj = new MobilePurchaseSystemCustomer();
	}
	@Test
	public void setCustomerTest() throws Exception
	{ 
	Date d= new Date();
	dtoObj.setCustomerName("Sakshi");
	dtoObj.setMailId("c@gmail.com");
	dtoObj.setPhoneNumber("9898787678");
	dtoObj.setPurchaseDate(d);
	dtoObj.setMobileId(1001);
	try
	{
	int purchaseId = mpDao.details(dtoObj).getPurchaseId();
	Assert.assertNotSame(0,purchaseId);
	}
	catch ( MobilePurchaseException e )
	{
	Assert.fail();
	}
	}
	@Test
	public void Test6() throws MobilePurchaseException  {
	ArrayList<MobilePurchaseSystemCustomer> sm = new ArrayList<MobilePurchaseSystemCustomer>();
	MobilePurchaseSystemCustomer sm1= new MobilePurchaseSystemCustomer();
	sm1.setMobileId(1002);
	sm1.setName("Samsung Galaxy IV");
	sm1.setPrice(38000);
	sm1.setQuantity(37);
	sm = mpDao.SearchMobile(30000,40000);
	if (sm != null) 
	{
	Iterator<MobilePurchaseSystemCustomer> i = sm.iterator();
	while (i.hasNext()) 
	{
		MobilePurchaseSystemCustomer obj = (MobilePurchaseSystemCustomer) i
	.next();
	//  Assert.assertNotSame(obj,sm1);
	Assert.assertNotSame(0,obj.getMobileId());
	Assert.assertNotSame("samsung",obj.getName());
	Assert.assertNotSame(35000,obj.getPrice());
	Assert.assertNotSame(28,String.valueOf(obj.getQuantity()));
	}
	}
	}
	}



