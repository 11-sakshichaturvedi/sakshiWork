package com.capgemini.mobilepurchase.dao;

import java.util.ArrayList;

import com.capgemini.mobilepurchase.dto.MobilePurchaseSystemCustomer;
import com.capgemini.mobilepurchase.exceptions.MobilePurchaseException;



public interface mobilePurchaseDao {
	//public String addDonorDetails(DonorBean donor) throws DonorException;
	public MobilePurchaseSystemCustomer details(MobilePurchaseSystemCustomer m) throws MobilePurchaseException;
		
	public int getPurchaseId() throws MobilePurchaseException;
	public ArrayList<String> getMobileId() throws MobilePurchaseException;
	public ArrayList<MobilePurchaseSystemCustomer> SearchMobile(int min,int max) throws MobilePurchaseException;
	//public ArrayList<MobilePurchaseSystemCustomer> delete_mobile(int mid)throws MobilePurchaseException;
	public int deleteRecords(int delete) throws MobilePurchaseException;
}

