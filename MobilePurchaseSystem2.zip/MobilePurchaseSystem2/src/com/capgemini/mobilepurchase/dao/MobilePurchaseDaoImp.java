package com.capgemini.mobilepurchase.dao;

import java.sql.*;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;





import com.capgemini.mobilepurchase.dto.MobilePurchaseSystemCustomer;
import com.capgemini.mobilepurchase.exceptions.MobilePurchaseException;
import com.capgemini.mobilepurchase.util.DBConnection;

public class MobilePurchaseDaoImp implements mobilePurchaseDao{
	int purchaseId;
MobilePurchaseSystemCustomer m = new MobilePurchaseSystemCustomer();
	private Logger logger=Logger.getLogger(MobilePurchaseDaoImp.class);
	//------------------------ 1. MobilePurchaseSystem--------------------------
		/*******************************************************************************************************
		 - Function Name	:	details(MobilePurchaseSystemCustomer m)
		 - Input Parameters	:	dtoObj
		 - Return Type		:	MobilePurchaseSystemCustomer
		 - Throws			:  MobilePurchaseException
		 - Author			:	Sakshi Chaturvedi
		 - Creation Date	:	28/01/2019
		 - Description		:	ViewMobileDetails
		 ********************************************************************************************************/
	@Override 
	public MobilePurchaseSystemCustomer details(MobilePurchaseSystemCustomer m) 
			throws MobilePurchaseException{
		PropertyConfigurator.configure("log4j.properties");
		
		
		Connection conn;
		PreparedStatement insertStmt=null;
		conn=DBConnection.getConnection();
		//System.out.println(conn);
		try{
			
			java.util.Date udate = m.getPurchaseDate();
			java.sql.Date sdate = new java.sql.Date(udate.getTime());
			
			insertStmt=conn.prepareStatement(IQueryMapper.INSERT_QUERY);
			//insertStmt.setInt(1,m.getPurchaseId());
			insertStmt.setString(1,m.getCustomerName());
			insertStmt.setString(2,m.getMailId());
			insertStmt.setString(3,m.getPhoneNumber());
		
			insertStmt.setDate(4,sdate);
			insertStmt.setInt(5,m.getMobileId());
			
			int result=insertStmt.executeUpdate();
			
			if(result!=1){
				logger.debug("value not inserted");
				throw new MobilePurchaseException("sorry!cant process your request");
			}else{
				purchaseId=getPurchaseId();
				m.setPurchaseId(purchaseId);
				insertStmt=conn.prepareStatement(IQueryMapper.UPDATE_QUERY);
				insertStmt.setInt(1,m.getMobileId());
				insertStmt.executeUpdate();
				conn.commit();
				//insertStmt.close();
				//conn.close();
				
			}
			
		}
		catch(SQLException| NullPointerException e)
		{
			//logger.error(e);
			throw new MobilePurchaseException("Tehnical problem occured refer log");
	//e.printStackTrace();

		}//finally{
			
				
			//}
			
		
		return m;
	}
	//------------------------ 2. MobilePurchaseSystem--------------------------
			/*******************************************************************************************************
			 - Function Name	:	getPurchaseId())
			
			 - Return Type		:	int
			 - Throws			:  MobilePurchaseException
			 - Author			:	Sakshi Chaturvedi
			 - Creation Date	:	28/01/2019
			 - Description		:	fetch purchaseID
			 ********************************************************************************************************/
	public int getPurchaseId() throws MobilePurchaseException{
		Connection conn;
		PreparedStatement getPurchaseIdStmt = null;
		ResultSet idResult = null;
		int purchaseId=0;
		
			conn = DBConnection.getConnection();
			try {
				getPurchaseIdStmt =  conn.prepareStatement(IQueryMapper.GET_Purchase_ID);
				idResult=getPurchaseIdStmt.executeQuery();
				if(idResult.next()){
			purchaseId =idResult.getInt(1);
			logger.info("Purchase Id:" +purchaseId);
				}
			}
	catch(SQLException e ) {
		// TODO Auto-generated catch block
		//e.printStackTrace();
		logger.error(e.getMessage());
		throw new MobilePurchaseException("Sorry!!!");
	}
			finally
			{
				try{
					if(idResult != null)
						idResult.close();
					if(getPurchaseIdStmt != null)
						getPurchaseIdStmt.close();
				}catch(SQLException exception2){
					logger.error(exception2.getMessage());
					//throw new MobilePurchaseException(exception2.getMessage());
				}
			}
		
		return purchaseId;
}
	//------------------------ 3. MobilePurchaseSystem--------------------------
			/*******************************************************************************************************
			 - Function Name	:	getMobileId()
			
			 - Return Type		:	ArrayList<String>
			 - Throws			:  MobilePurchaseException
			 - Author			:	Sakshi Chaturvedi
			 - Creation Date	:	28/01/2019
			 - Description		:	Display MobileID
			 ********************************************************************************************************/
	public ArrayList<String> getMobileId() throws MobilePurchaseException{
		Connection conn=null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		ArrayList<String> list =new ArrayList<String>(); 
	

		try {
			conn = DBConnection.getConnection();
			preparedStatement = conn.prepareStatement(IQueryMapper.GET_MobileId);
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				list.add(resultSet.getString("mobileid"));
				
			}
			
		} catch ( MobilePurchaseException | SQLException e) {
			throw new MobilePurchaseException("sorry not fetching the Purchase Id");
			
		}
		System.out.println("The list contains:" + list);
		return list;
		
	}
	//------------------------ 4. MobilePurchaseSystem--------------------------
			/*******************************************************************************************************
			 - Function Name	:	SearchMobile(int min,int max)
			 - Input Parameters	:	min and max
			 - Return Type		:	ArrayList<MobilePurchaseSystemCustomer>
			 - Throws			:  MobilePurchaseException
			 - Author			:	Sakshi Chaturvedi
			 - Creation Date	:	28/01/2019
			 - Description		:	Search mobileDEtails
			 ********************************************************************************************************/
	
	public ArrayList<MobilePurchaseSystemCustomer> SearchMobile(int min,int max) throws MobilePurchaseException{
		
		Connection conn=null;
		PreparedStatement getsearchStmt = null;
		ResultSet searchResult = null;
		ArrayList<MobilePurchaseSystemCustomer> listSearch =new ArrayList<MobilePurchaseSystemCustomer>(); 
		try{
	conn = DBConnection.getConnection();
	getsearchStmt = conn.prepareStatement(IQueryMapper.Search_query);
		getsearchStmt.setInt(1,min);
		getsearchStmt.setInt(2,max);
		searchResult=getsearchStmt.executeQuery();
		while(searchResult.next()){
			MobilePurchaseSystemCustomer m=new MobilePurchaseSystemCustomer();
			m.setMobileId(searchResult.getInt(1));
			m.setName(searchResult.getString(2));
			m.setPrice(searchResult.getDouble(3));
			m.setQuantity(searchResult.getInt(4));
			listSearch.add(m);}}
			catch(SQLException e ) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				//logger.error(e.getMessage());
				//System.out.println(e);
			}
			catch(MobilePurchaseException exception2){
							logger.error(exception2.getMessage());
							System.out.println(exception2);
						}
		//System.out.println("The list contains:" + listSearch);
		return listSearch;
		
	
	}
	//------------------------ 5. MobilePurchaseSystem--------------------------
			/*******************************************************************************************************
			 - Function Name	:	delete_mobile(int mid)
			 - Input Parameters	:   MobileId
			 - Return Type		:	ArrayList<MobilePurchaseSystemCustomer>
			 - Throws			:  MobilePurchaseException
			 - Author			:	Sakshi Chaturvedi
			 - Creation Date	:	28/01/2019
			 - Description		:	Delete Mobile Details
			 ********************************************************************************************************/
	/*public ArrayList<MobilePurchaseSystemCustomer> delete_mobile(int mid)throws MobilePurchaseException{
		Connection conn;
		PreparedStatement deleteStmt1 = null;
		PreparedStatement deleteStmt2 = null;
		ResultSet deleteResult1 = null;
		ResultSet deleteResult2 = null;
		ArrayList<MobilePurchaseSystemCustomer> delete = new ArrayList<MobilePurchaseSystemCustomer>();
		
		
		try{	
		conn = DBConnection.getConnection();
		deleteStmt1 = conn.prepareStatement(IQueryMapper.Delete_custDetail);
		deleteStmt1.setInt(1, mid);
		deleteResult1=deleteStmt1.executeQuery();
		
		deleteStmt2 = conn.prepareStatement(IQueryMapper.Delete_Mobile);
		deleteStmt2.setInt(1, mid);	
		deleteResult2=deleteStmt2.executeQuery();
		
			while(deleteResult2.next())
			{
				MobilePurchaseSystemCustomer m=  new MobilePurchaseSystemCustomer();
				
			m = new MobilePurchaseSystemCustomer();
			m.setMobileId(deleteResult2.getInt(1));
			m.setName(deleteResult2.getString(2));
			m.setPrice(deleteResult2.getDouble(3));
			m.setQuantity(deleteResult2.getInt(4));
			delete.add(m);
			}
			
		}	

catch(MobilePurchaseException | SQLException e){
				//logger.error(e.getMessage());
				//System.out.println(e);
			}
		return delete;
	}*/
	public int deleteRecords(int delete) throws MobilePurchaseException{
		Connection conn;
		PreparedStatement delStmt=null;
		try{//Delete_custDetail
			conn=DBConnection.getConnection();
			delStmt=conn.prepareStatement(IQueryMapper.Delete_Mobile);
			delStmt.setInt(1, delete);
			//int deleteResult=delStmt.executeUpdate();
			//delStmt=conn.prepareStatement(IQueryMapper.Delete_custDetail);
			//delStmt.setInt(1, delete);
			int deleteResult=delStmt.executeUpdate();
			if(deleteResult!=1){
				//logger.error("Deletion Failed");
				throw new MobilePurchaseException("Deleting records Failed");
			}
			else
				conn.close();
		}catch(MobilePurchaseException|SQLException e){
			//e.printStackTrace();
			System.out.println("record not found");
		}			
		return delete;
	}

}



