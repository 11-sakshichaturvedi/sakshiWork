package com.capgemini.mobilepurchase.dao;

public interface IQueryMapper {

		public static final String INSERT_QUERY="insert into purchasedetails values(sequ.nextval,?,?,?,?,?)";
		public static final String GET_Purchase_ID = "select sequ.currval from dual";
		
		public static final String GET_MobileId="select mobileid from mobiles";
		public static final String UPDATE_QUERY="update mobiles set quantity =(quantity-1) where mobileId=?";
       public static final String Search_query="select * from mobiles where price BETWEEN ? AND ?";
       public static final String Delete_Mobile = "delete from mobiles where mobileid = ?";
      // public static final String Delete_custDetail = "delete from purchasedetails where mobileid = ?";
       public static final String GET_MOBILES="SELECT *FROM MOBILES";
   	
   	//public static final String UPDATE_STOCK= "UPDATE MOBILES SET QUANTITY=QUANTITY-1 WHERE MOBILEID=?";
   	
   	public static final String GET_STOCK= "SELECT QUANTITY FROM MOBILES WHERE QUANTITY=?";
}



