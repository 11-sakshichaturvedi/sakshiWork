package com.capgemini.mobilepurchase.presentation;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
//import java.util.Random;
import java.util.Scanner;





//import com.capgemini.mobilepurchase.dao.MobilePurchaseDaoImp;
import com.capgemini.mobilepurchase.dto.MobilePurchaseSystemCustomer;
import com.capgemini.mobilepurchase.exceptions.MobilePurchaseException;
import com.capgemini.mobilepurchase.service.MobileServiceImpl;

public class Client {
	static MobileServiceImpl e;
	static MobilePurchaseSystemCustomer m;
	private static Scanner sc;

	public static void main(String[] args) throws MobilePurchaseException, SQLException {

		sc = new Scanner(System.in);
		System.out.println("welcome to mobile purchase system");
		String choice = "initial";
		while (true) {
			System.out.println("enter your choice");
			System.out.println("1.customer details and purchase details");
			System.out.println("2.search");
			System.out.println("3.delete");
			System.out.println("4.exit");
			choice = sc.next().trim();

			switch (choice) {
			case "1":
				int option = 1;
					System.out
							.println("DO U WANT TO CONTINUE enter 1 else press any other to  exit");
					option = sc.nextInt();
					if(option==1)
						getInputs();
					else
					{
						System.out.println("Wrong option chosen");
					}
					break;
			case "2":
				System.out.println("search");
				int max;
				int min;
				System.out.println("enter the min price");
				min=sc.nextInt();
				System.out.println("enter the max price");
				max=sc.nextInt();
				SearchMobile(min,  max);
				break;
			case "3":
			
				
				//System.out.println("enter the mobile id u want to delete");
				//mid=sc.nextInt();
				deleteRecords();
				break;

			case "4":
				System.out.println("thank you!");
				System.exit(0);
				break;
			default:
				System.out.println("enter valid choice");
				break;
			}
		}
	}
	//------------------------ 1. MobilePurchaseSystem--------------------------
	/*******************************************************************************************************
	 - Function Name	:	getInputs()
	 
	 - Return Type		:	void
	 - Throws			:  MobilePurchaseException
	 - Author			:	Sakshi Chaturvedi
	 - Creation Date	:	28/01/2019
	 - Description		:	input details of mobile purchase system
	 ********************************************************************************************************/
	private static void getInputs() throws MobilePurchaseException, SQLException {
		e = new MobileServiceImpl();
		m = new MobilePurchaseSystemCustomer();

		// MobilePurchaseDaoImp dao = new MobilePurchaseDaoImp();

		String customerName = "";

		String mailId = "";

		String phoneNumber = "";
		String mobileId = "";
	int purchaseId  ;
		
		 Date purchaseDate=new Date(); 
		while (true) {

			System.out.println("please enter your customer name");
			customerName = sc.next();

			if (e.validatecustomerName(customerName) == true) {
				break;
			} else {
				System.out.println("Please enter first letter in upper case");
			}

		}

		while (true) {

			System.out.println("please enter your mailid");
			mailId = sc.next();

			if (e.validatemailId(mailId) == true) {
				break;
			} else {
				System.err.println("Please enter valid emailid");

			}

		}
		while (true) {

			System.out.println("please enter your phone number");
			phoneNumber = sc.next();

			if (e.validatephone(phoneNumber) == true) {
				break;
			} else {
				System.err
						.println("Please enter valid phone number of 10 digits");

			}

		}
		int count = 3;

		boolean status=true;
		while (status) {
			ArrayList<String> mobilelist = new ArrayList<String>();
			mobilelist= e.getMobileId();
			System.out.println("available mobile IDs:" +mobilelist);
			System.out.println("Enter mobile Id");
			mobileId = sc.next();
			
			if (e.validatemobileID(mobileId) == true) 
			{
				if(mobilelist.contains(mobileId))
				{
				break;
				}
				else
				{
					System.out.println("Enter only valid mobile ids in th list");
				}
			}
			
			else
			{			
				System.out.println("invalid mobile Id");	
				count--;
				if(count == 0)
					status = false;
			}
		}
		/*while (true) {

			System.out.println("please enter your mobileId");
			mobileId = sc.next();

			if (e.validatemobileID(mobileId) == true) {
				// String str=Long.toString(phoneNumber);
				// fltype=Integer.parseInt(type);
				break;
			} else {
				System.err.println("Please enter valid mobileId in 4 digits");

			}

		}
*/
		

		/*
		 * SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy"); Date
		 * date = new Date(); System.out.println(formatter.format(date));
		 * purchaseDate=date;
		 */
		/*
		 * java.util.Date utilDate = new java.util.Date(); java.sql.Date
		 * purchaseDate = new java.sql.Date(utilDate.getTime());
		 * 
		 * System.out.println("purchaseDate:" + purchaseDate);
		 */
		//m.setPurchaseId(purchaseId);
		m.setCustomerName(customerName);
		m.setMailId(mailId);
		m.setPhoneNumber(phoneNumber);
		m.setMobileId(Integer.parseInt(mobileId));
		
m.setPurchaseDate(purchaseDate);
		// m.setPurchaseDate(purchaseDate);
		m = e.details(m);
		// e.getPurchaseId();
		 System.out.println("purchaseid ="+m.getPurchaseId());
		 
		
			//System.out.println("hii");
		//System.out.println(mob.getPurchaseID());
			 System.out.println("customerName= "+m.getCustomerName()+"\nmailID= "+m.getMailId()
						+"\nPhoneNumber= "+m.getPhoneNumber()+"\nPurchaseDate= "+m.getPurchaseDate()+"\n");
				
						
						System.out.println("\n");
	}
	//------------------------  mobile details MobilePurchaseSystem--------------------------
		/*******************************************************************************************************
		 - Function Name	:	SearchMobile(int min, int max)
		 - Input Parameters	:	min max
		 - Return Type		:	void
		 - Throws			:  MobilePurchaseException
		 - Author			:	Sakshi Chaturvedi
		 - Creation Date	:	28/01/2019
		 - Description		:	search
		 ********************************************************************************************************/
	public static void SearchMobile(int min, int max) throws MobilePurchaseException{
		//System.out.println("hii");
		MobileServiceImpl serv;
		serv=new MobileServiceImpl();
		ArrayList<MobilePurchaseSystemCustomer> mobile = new ArrayList<MobilePurchaseSystemCustomer>();
		mobile = serv.SearchMobile(min,max);
		System.out.println("Search Result");
		if(mobile != null){
			Iterator<MobilePurchaseSystemCustomer> itr = mobile.iterator();
			while(itr.hasNext()){
				MobilePurchaseSystemCustomer mob = (MobilePurchaseSystemCustomer)itr.next();
			System.out.println(mob.getMobileId());
			System.out.println("mobile id "+mob.getMobileId()+"  name "+mob.getName()+"  price "+mob.getPrice()+"  quantity "+mob.getQuantity());
/*
			System.out.println(mob.getName());
			System.out.println(mob.getPrice());
			System.out.println(mob.getQuantity());*/
		}}
		else{
			System.out.println("There are no such record in the store");
			

}}
	//------------------------  mobile details MobilePurchaseSystem--------------------------
	/*******************************************************************************************************
	 - Function Name	:	delete_mobile(int mid)
	 - Input Parameters	:	mid
	 - Return Type		:	void
	 - Throws			:  MobilePurchaseException
	 - Author			:	Sakshi Chaturvedi
	 - Creation Date	:	28/01/2019
	 - Description		:	delete
	 ********************************************************************************************************/
	/*public static void delete_mobile(int mid)throws MobilePurchaseException{
		MobileServiceImpl serv;
		serv=new MobileServiceImpl();
		ArrayList<MobilePurchaseSystemCustomer> delete = new ArrayList<MobilePurchaseSystemCustomer>();
		delete = serv.delete_mobile(mid);
		System.out.println("This Record Deleted");
		if(delete != null){
			Iterator<MobilePurchaseSystemCustomer> itr = delete.iterator();
			while(itr.hasNext()){
				MobilePurchaseSystemCustomer mob = (MobilePurchaseSystemCustomer)itr.next();
			//System.out.println("mobile id "+mob.getMobileId()+"name "+mob.getName()+"price "+mob.getPrice()+"quantity "+mob.getQuantity());
			
		}}
		else{
			System.out.println("There are no such record in the store");
			}
		
	}*/
	//static MobileServiceImpl mobileService=null;
	
	private static void deleteRecords() throws MobilePurchaseException{
		e = new MobileServiceImpl();
		System.out.println("Enter a mobile id to delete:");
		
		int deleteId=sc.nextInt();
		e.deleteRecords(deleteId);
	   // System.out.println(deleteId+" "+e.deleteRecords(deleteId));
		//System.out.println("Records Deleted");

	}
		

		}

// flat.setOwnerId(ownerid);

