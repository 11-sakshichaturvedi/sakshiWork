package com.capgemini.mobilepurchase.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;




import com.capgemini.mobilepurchase.dao.MobilePurchaseDaoImp;
import com.capgemini.mobilepurchase.dto.MobilePurchaseSystemCustomer;
import com.capgemini.mobilepurchase.exceptions.MobilePurchaseException;

public class MobileServiceImpl implements MobileService{
	MobilePurchaseDaoImp dao1;
//make constructor and object of dao class
	public  MobileServiceImpl(){
		
		dao1= new MobilePurchaseDaoImp();
		
	}
	
	//override the dao method and returntype as dto class
	@Override
	public MobilePurchaseSystemCustomer details(MobilePurchaseSystemCustomer m) 
			throws MobilePurchaseException{
			
		return dao1.details(m);
	}
	public int getPurchaseId() throws MobilePurchaseException{
		return dao1.getPurchaseId();
	}
	
	public ArrayList<String> getMobileId() throws SQLException, MobilePurchaseException
	{
				return dao1.getMobileId();
			}
	public ArrayList<MobilePurchaseSystemCustomer> SearchMobile(int min,int max) throws MobilePurchaseException{
		
		return dao1.SearchMobile( min, max);
	}
	/*public ArrayList<MobilePurchaseSystemCustomer> delete_mobile(int mid)throws MobilePurchaseException{

		return dao1.delete_mobile(mid);
	}*/

	@Override
	public int deleteRecords(int delete) throws MobilePurchaseException {
		// TODO Auto-generated method stub
		System.out.println("delete");
		return dao1.deleteRecords(delete);
	}


	//------------------------  mobile details MobilePurchaseSystem--------------------------
		/*******************************************************************************************************
		 - Function Name	:	validatecustomerName(String Name)
		 - Input Parameters	:	name
		 - Return Type		:	boolean
		
		 - Author			:	Sakshi Chaturvedi
		 - Creation Date	:	28/01/2019
		 - Description		:	validate name
		 ********************************************************************************************************/
public boolean validatecustomerName(String Name) {
		
		Pattern idPattern = Pattern.compile("[A-Z][a-z]{1,19}");
		Matcher idMatcher = idPattern.matcher(Name);
		
		if(idMatcher.matches())
			return true;
		else
			return false;	
		
	}

//------------------------  mobile details MobilePurchaseSystem--------------------------
		/*******************************************************************************************************
		 - Function Name	:	validatemailId(String mailId)
		 - Input Parameters	:	mailId
		 - Return Type		:	boolean
		
		 - Author			:	Sakshi Chaturvedi
		 - Creation Date	:	28/01/2019
		 - Description		:	validate mailId
		 ********************************************************************************************************/
public boolean validatemailId(String mailId){
	Pattern idPattern = Pattern.compile("[a-z]{1,10}[@][a-z]{1,10}[.][a-z]{1,5}");
	Matcher idMatcher = idPattern.matcher(mailId);
	
	if(idMatcher.matches())
		return true;
	else
		return false;
	
}

//------------------------  mobile details MobilePurchaseSystem--------------------------
		/*******************************************************************************************************
		 - Function Name	:	validatephone(String phoneNumber)
		 - Input Parameters	:	phone number
		 - Return Type		:	boolean
		
		 - Author			:	Sakshi Chaturvedi
		 - Creation Date	:	28/01/2019
		 - Description		:	validate phoneNumber
		 ********************************************************************************************************/
public boolean validatephone(String phoneNumber){
	//String str=Long.toString(phoneNumber);
	Pattern idPattern = Pattern.compile("[0-9]{10}");
	Matcher idMatcher = idPattern.matcher(phoneNumber);
	
	if(idMatcher.matches())
		return true;
	else
		return false;
}

//validatemobileID
//------------------------  mobile details MobilePurchaseSystem--------------------------
		/*******************************************************************************************************
		 - Function Name	:	validatemobileID(String mobileId)
		 - Input Parameters	:	mobileId
		 - Return Type		:	boolean
		
		 - Author			:	Sakshi Chaturvedi
		 - Creation Date	:	28/01/2019
		 - Description		:	validate mobileId
		 ********************************************************************************************************/
public boolean validatemobileID(String mobileId){
	//String str=Long.toString(phoneNumber);
	Pattern idPattern = Pattern.compile("[0-9]{4}");
	Matcher idMatcher = idPattern.matcher(mobileId);
	
	if(idMatcher.matches())
		return true;
	else
		return false;
}}
