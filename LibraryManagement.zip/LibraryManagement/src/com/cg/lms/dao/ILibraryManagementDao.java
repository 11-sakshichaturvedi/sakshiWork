package com.cg.lms.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.lms.dto.BookInventoryDto;
import com.cg.lms.dto.BookRegistrationDto;
import com.cg.lms.dto.BooksTransactionDto;
import com.cg.lms.dto.UsersDto;
import com.cg.lms.exceptions.LibraryManagementException;

public interface ILibraryManagementDao {
	public UsersDto setValues(UsersDto userDtoObj)throws LibraryManagementException;
	public UsersDto login(UsersDto userDtoObj)throws LibraryManagementException, SQLException;
	public String statusMethod() throws LibraryManagementException;
	public BookInventoryDto inventory(BookInventoryDto bookIDto) throws LibraryManagementException;
	 public ArrayList<BookInventoryDto> getDisplay()throws LibraryManagementException;
	 public String delRecordsSql(String del) throws LibraryManagementException;
	 public BookRegistrationDto userRequest(BookRegistrationDto regDto) throws LibraryManagementException ;
	 public String getRegistrationId()throws LibraryManagementException, SQLException;
	 public ArrayList<BookRegistrationDto> getRequest()throws LibraryManagementException;
	 public BooksTransactionDto transactionMethod(BooksTransactionDto traDto)throws LibraryManagementException,SQLException;
	 public String getTransactionId() throws LibraryManagementException, SQLException;
	 public BooksTransactionDto updateReturn(BooksTransactionDto traDto)throws LibraryManagementException, SQLException;
	 public BooksTransactionDto updateFine(BooksTransactionDto traDto) throws LibraryManagementException, SQLException;
		public ArrayList<BooksTransactionDto> getDisplayFine()throws LibraryManagementException;
	 public Double displayFine(BooksTransactionDto traDto) throws LibraryManagementException, SQLException;

}
