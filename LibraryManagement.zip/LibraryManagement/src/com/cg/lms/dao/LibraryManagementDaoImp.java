package com.cg.lms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;













import com.cg.lms.dto.BookInventoryDto;
import com.cg.lms.dto.BookRegistrationDto;
import com.cg.lms.dto.BooksTransactionDto;
import com.cg.lms.dto.UsersDto;
import com.cg.lms.exceptions.LibraryManagementException;
import com.cg.lms.presentation.LibraryUI;
import com.cg.lms.util.DBConnection;



public class LibraryManagementDaoImp implements ILibraryManagementDao{
	Connection conn;
	//String mobileId=null;
	PreparedStatement insertstmt=null;
String lib;
Double fine;
UsersDto userDtoObj=new UsersDto();

	public UsersDto setValues(UsersDto userDtoObj)throws LibraryManagementException{
		
		
			
		try{
			
			conn=DBConnection.getConnection();
			insertstmt=conn.prepareStatement(IQueryMapper.INSERT_QUERY);
		    //insertstmt.setInt(1,cust.getPurchaseId());
	        insertstmt.setString(1,userDtoObj.getUser_id());
	        insertstmt.setString(2,userDtoObj.getUser_name());
		    insertstmt.setString(3,userDtoObj.getPassword());
		    insertstmt.setString(4,userDtoObj.getEmail_id());
		    insertstmt.setString(5,userDtoObj.getLibrarian());
		    int result=insertstmt.executeUpdate();
		    if(result!=1){
				//logg.info("value not inserted");
				throw new LibraryManagementException("sorry!cant process your request");
			}else{
				//conn.commit();
			}
			
		}
		catch(Exception e)
		{
			
			System.out.println(e.getMessage());
			
		
			
		}
		return userDtoObj;
	}
	public UsersDto login(UsersDto userDtoObj)throws LibraryManagementException,SQLException{
		
		try{
			
			conn=DBConnection.getConnection();
			insertstmt = conn.prepareStatement(IQueryMapper.Login_QUERY);
			
			//ResultSet result=insertstmt.executeQuery();
			//PreparedStatement login = connection.prepareStatement(sqlString);
			insertstmt.setString(1,userDtoObj.getUser_id());
			insertstmt.setString(2,userDtoObj.getPassword());
			ResultSet rs = insertstmt.executeQuery();
			if( rs.next()){
		        //return true;
				System.out.println("login sucessfull");
				lib =rs.getString(1);
			//System.out.println(lib);
			    //insertstmt.setString(5,userDtoObj.getLibrarian());

			
		   } else {
		       //return false;
			   System.out.println("u have enter wrong credentials!\n please enter your Id and Password again!");
			   LibraryUI ui= new LibraryUI();
			   ui.loginPage();
			   
		   }
		    
			
		}
		catch(Exception e)
		{
			
			System.out.println(e.getMessage());
			
		
			
		}
		return userDtoObj;
	}
public String statusMethod(String idd) throws LibraryManagementException{
	System.out.println("passing lib from dao");
	
	//System.out.println("passing lib from dao");
	Connection conn;
	PreparedStatement getPurchseIdstmt=null;
	ResultSet regresult=null;
     String BookId="";
     BooksTransactionDto regDto=new BooksTransactionDto();
    try{
    	//System.out.println("hi");
    	//System.out.println(idd);
	conn=DBConnection.getConnection();
	getPurchseIdstmt=conn.prepareStatement(IQueryMapper.selectlib);
	//insertstmt.setString(1,traDto.getTransaction_Id());
	getPurchseIdstmt.setString(1,idd);
	//insertstmt.setString(1,regDto.getRegistration_id());
	//insertstmt.setString(1,traDto.getTransaction_Id());
	//System.out.println("hi");
	System.out.println("tid");
	regresult=getPurchseIdstmt.executeQuery();
	while(regresult.next()){
		UsersDto m=new UsersDto();
		m.setLibrarian(regresult.getString(1));
		//m.setFine(searchResult.getDouble(6));
		//listSearch.add(m);
		BookId=m.getLibrarian();
		System.out.println(BookId);
		}}
		catch(SQLException e ) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			//logger.error(e.getMessage());
			//System.out.println(e);
		}
		catch(LibraryManagementException exception2){
						//logger.error(exception2.getMessage());
						System.out.println(exception2);
					}
	//System.out.println("The list contains:" + listSearch);
	return BookId;
	


}
public BookInventoryDto inventory(BookInventoryDto bookIDto) throws LibraryManagementException {
	try{
		
		conn=DBConnection.getConnection();
		insertstmt=conn.prepareStatement(IQueryMapper.INSERT_Inventory);
	    //insertstmt.setInt(1,cust.getPurchaseId());
        insertstmt.setString(1,bookIDto.getBook_id());
        insertstmt.setString(2,bookIDto.getBook_name());
	    insertstmt.setString(3,bookIDto.getAuthor1());
	    insertstmt.setString(4,bookIDto.getAuthor2());
	    insertstmt.setString(5,bookIDto.getPublisher());
	    insertstmt.setString(6,bookIDto.getYearOfPublication());
         insertstmt.setString(7,bookIDto.getAvailabiity());

	    //insertstmt.setString(5,userDtoObj.getLibrarian());
	    int result=insertstmt.executeUpdate();
	    if(result!=1){
			//logg.info("value not inserted");
			throw new LibraryManagementException("sorry!cant process your request");
		}else{
			//conn.commit();
		}
		
	}
	catch(Exception e)
	{
		
		System.out.println(e.getMessage());
		
	
		
	}
	
	
	return bookIDto;
}

public ArrayList<BookInventoryDto> getDisplay()throws LibraryManagementException{
	ArrayList <BookInventoryDto> lis=new ArrayList();
	Connection conn;
	PreparedStatement pstmt=null;
	try{
		conn=DBConnection.getConnection();
		pstmt=conn.prepareStatement(IQueryMapper.display_Inventory);
		ResultSet results=pstmt.executeQuery();
		while(results.next()){
			//logg.fatal("Getting the details of all mobiles");
			BookInventoryDto dbobj=new BookInventoryDto();
			dbobj.setBook_id(results.getString(1));
			dbobj.setBook_name(results.getString(2));
			dbobj.setAuthor1(results.getString(3));
			dbobj.setAuthor2(results.getString(4));
			dbobj.setPublisher(results.getString(5));
			dbobj.setYearOfPublication(results.getString(6));
			dbobj.setAvailabiity(results.getString(7));
			lis.add(dbobj);
		}
	}catch(Exception e){
		System.err.println(e);
	}
	return lis;
}
public String delRecordsSql(String del) throws LibraryManagementException {
	Connection conn = DBConnection.getConnection();
	PreparedStatement preDel = null;

	try {
		preDel = conn.prepareStatement(IQueryMapper.DELETE_Records);
		preDel.setString(1, del);
		int result = preDel.executeUpdate();
		if (result != 1) {
			//logg.debug("Deletion failed ");
			throw new LibraryManagementException("Deletion failed or Id not Available");
		} else {
			System.out.println("Record deleted..!!");
			//conn.close();
		}

	} catch (SQLException e) {

		e.printStackTrace();
	}
	return del;

}//DELETE_Records

public String delRequestSql(String del) throws LibraryManagementException {
	Connection conn = DBConnection.getConnection();
	PreparedStatement preDel = null;

	try {
		preDel = conn.prepareStatement(IQueryMapper.DELETE_Request);
		preDel.setString(1, del);
		int result = preDel.executeUpdate();
		if (result != 1) {
			//logg.debug("Deletion failed ");
			throw new LibraryManagementException("Deletion failed or Id not Available");
		} else {
			//System.out.println("Record deleted..!!");
			//conn.close();
		}

	} catch (SQLException e) {

		e.printStackTrace();
	}
	return del;

}
public String delTransaction(String del) throws LibraryManagementException {
	Connection conn = DBConnection.getConnection();
	PreparedStatement preDel = null;

	try {
		preDel = conn.prepareStatement(IQueryMapper.DeleteTransaction);
		preDel.setString(1, del);
		int result = preDel.executeUpdate();
		if (result != 1) {
			//logg.debug("Deletion failed ");
			throw new LibraryManagementException("Deletion failed or Id not Available");
		} else {
			System.out.println("user paid..!!");
			//conn.close();
		}

	} catch (SQLException e) {

		e.printStackTrace();
	}
	return del;

}
public BookRegistrationDto userRequest(BookRegistrationDto regDto) throws LibraryManagementException {
	try{
		//UsersDto userdto=new UsersDto();
	conn=DBConnection.getConnection();
		//java.util.Date udate=customerMps.getPurchaseDate();
		//java.sql.Date sdate=new java.sql.Date(udate.getTime());
		insertstmt=conn.prepareStatement(IQueryMapper.INSERT_request);
	    //insertstmt.setInt(1,cust.getPurchaseId());
        insertstmt.setString(1,regDto.getBook_Id());
        insertstmt.setString(2,regDto.getUser_Id());
        insertstmt.setString(3,regDto.getStatusreq());
        int result=insertstmt.executeUpdate();
       // userDtoObj.setUser_id(result.getString("User_Id");

	    //insertstmt.setString(5,userDtoObj.getLibrarian());
	    
	    if(result!=1){
			//logg.info("value not inserted");
			throw new LibraryManagementException("sorry!cant process your request");
		}else{
			//conn.commit();
		}
		
	}
	catch(Exception e)
	{
		
		System.out.println(e.getMessage());
		
	
		
	}
	
	
	return regDto;
}
@Override
public String getRegistrationId()throws LibraryManagementException, SQLException{
	Connection conn;
	PreparedStatement getPurchseIdstmt=null;
	ResultSet regresult=null;
     String registrationId="";
    try{
	conn=DBConnection.getConnection();
	getPurchseIdstmt=conn.prepareStatement(IQueryMapper.GET_RID);
	regresult=getPurchseIdstmt.executeQuery();
	while(regresult.next()){
		registrationId=regresult.getString(1);
		//System.out.println(registrationId);
	}
}catch(Exception e){
	System.out.print(e.getMessage());
}
		
	return registrationId;
}
public ArrayList<BookRegistrationDto> getRequest()throws LibraryManagementException{
	ArrayList <BookRegistrationDto> lis=new ArrayList<BookRegistrationDto>();
	Connection conn;
	PreparedStatement pstmt=null;
	try{
		conn=DBConnection.getConnection();
		pstmt=conn.prepareStatement(IQueryMapper.See_Req);
		ResultSet results=pstmt.executeQuery();
		while(results.next()){
			//logg.fatal("Getting the details of all mobiles");
			BookRegistrationDto dbobj=new BookRegistrationDto();
			dbobj.setRegistration_id(results.getString(1));;
			dbobj.setBook_Id(results.getString(2));
			dbobj.setUser_Id(results.getString(3));
			dbobj.setRegistrationdate(results.getDate(4));
			dbobj.setStatusreq(results.getString(5));
			lis.add(dbobj);
			conn.commit();
		}
	}catch(Exception e){
		System.err.println(e);
	}
	return lis;
}
public BooksTransactionDto transactionMethod(BooksTransactionDto traDto)throws LibraryManagementException,SQLException{

try{
		
		conn=DBConnection.getConnection();
		java.util.Date idate=traDto.getIssue_date();
		java.sql.Date sdate=new java.sql.Date(idate.getTime());
		java.util.Date rdate=traDto.getReturn_date();
		java.sql.Date rrdate=new java.sql.Date(rdate.getTime());
		java.util.Date adate=traDto.getActualReturn_date();
		java.sql.Date aadate=new java.sql.Date(adate.getTime());
	
		insertstmt=conn.prepareStatement(IQueryMapper.INSERT_transaction);
	    //insertstmt.setInt(1,cust.getPurchaseId());
        insertstmt.setString(1,traDto.getREGISTRATION_ID());
        insertstmt.setDate(2,sdate);
        insertstmt.setDate(3,rrdate);
        insertstmt.setDate(4,aadate);
      //  insertstmt.setDate(2,traDto.getActualReturn_date());
        insertstmt.setDouble(5,traDto.getFine());
        
        
	    //insertstmt.setString(5,userDtoObj.getLibrarian());
	    int result=insertstmt.executeUpdate();
	    if(result!=1){
			//logg.info("value not inserted");
			throw new LibraryManagementException("sorry!cant process your request");
		}else{
			//conn.commit();
		}
		
	}
	catch(Exception e)
	{
		
		//System.out.println(e.getMessage());
		
	
		
	}
	
	
	return traDto;
}
@Override
public String getTransactionId() throws LibraryManagementException, SQLException{
	Connection conn;
	PreparedStatement getPurchseIdstmt=null;
	ResultSet regresult=null;
     String registrationId="";
    try{
	conn=DBConnection.getConnection();
	getPurchseIdstmt=conn.prepareStatement(IQueryMapper.GET_TID);
	regresult=getPurchseIdstmt.executeQuery();
	while(regresult.next()){
		registrationId=regresult.getString(1);
		//System.out.println(registrationId);
	}
}catch(Exception e){
	System.out.print(e.getMessage());
}
		
	return registrationId;
}
public BooksTransactionDto updateReturn(BooksTransactionDto traDto)throws LibraryManagementException, SQLException{
	
	
	conn=DBConnection.getConnection();
	//BooksTransactionDto dto=new BooksTransactionDto();
	//System.out.println(conn);
	try{
		
		//java.util.Date udate = m.getPurchaseDate();
		//java.sql.Date sdate = new java.sql.Date(udate.getTime());
		//java.util.Date adate=traDto.getActualReturn_date();
		//java.sql.Date aadate=new java.sql.Date(adate.getTime());
		
		//insertstmt=conn.prepareStatement(IQueryMapper.INSERT_QUERY);
		//insertStmt.setInt(1,m.getPurchaseId());
		//insertstmt.setString(1,m.getCustomerName());
		////insertstmt.setString(2,m.getMailId());
		//insertstmt.setString(3,m.getPhoneNumber());
	
		//insertstmt.setDate(4,sdate);
		//insertstmt.setInt(5,m.getMobileId());
		
		//int result=insertstmt.executeUpdate();
		
		//if(result!=1){
			//logger.debug("value not inserted");
			//throw new LibraryManagementException("sorry!cant process your request");
		//}else{
			//purchaseId=getPurchaseId();
			//m.setPurchaseId(purchaseId);
		//System.out.println("after taking date in dao");
			insertstmt=conn.prepareStatement(IQueryMapper.update_actualDate);
			//insertstmt.setInt(1,m.getMobileId());
			insertstmt.setString(1,traDto.getTransaction_Id());
			//insertstmt.setDate(2,aadate);
			
			insertstmt.executeUpdate();
			conn.commit();
			//insertStmt.close();
			//conn.close();
			
		//}
		
	}
	catch(SQLException| NullPointerException e)
	{
		//logger.error(e);
		throw new LibraryManagementException("Tehnical problem occured refer log");
//e.printStackTrace();

	}//finally{
		
			
		//}
		
	
	//return m;


	return traDto;
}
//getFine
public BooksTransactionDto updateFine(BooksTransactionDto traDto) throws LibraryManagementException, SQLException{
	conn=DBConnection.getConnection();
	PreparedStatement pstmt=null;
	/*String query = "SELECT COF_NAME, PRICE FROM COFFEES";
	ResultSet rs = stmt.executeQuery(query);
	while (rs.next()) {
	    String s = rs.getString("COF_NAME");
	    float n = rs.getFloat("PRICE");
	    System.out.println(s + "   " + n);
		*/
	
		try{
			//String query="select return_date from bookstransaction where transaction_id =?";
			//pstmt=conn.prepareStatement(IQueryMapper.selectReturnDate);
			//insertstmt.setString(1,traDto.getTransaction_Id());
			
			
	insertstmt=conn.prepareStatement(IQueryMapper.update_fine);
	insertstmt.setString(1,traDto.getTransaction_Id());
	insertstmt.executeUpdate();
	conn.commit();
		
	}
	catch(SQLException| NullPointerException e)
	{
		//logger.error(e);
		throw new LibraryManagementException("Tehnical problem occured refer log");
//e.printStackTrace();

	}//finally{
		
			
		//}
		
	
	//return m;
	
	

	return traDto;
}
	//double fine=traDto.getFine();
	//traDto.setFine(fine);
	//purchaseId=getPurchaseId();
	//m.setPurchaseId(purchaseId);

public ArrayList<String> getregId() throws LibraryManagementException{
	Connection conn=null;
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;
	ArrayList<String> list =new ArrayList<String>(); 


	try {
		conn = DBConnection.getConnection();
		preparedStatement = conn.prepareStatement(IQueryMapper.GET_RegId);
		resultSet = preparedStatement.executeQuery();

		while (resultSet.next()) {
			list.add(resultSet.getString("REGISTRATION_ID"));
			
		}
		
	} catch ( LibraryManagementException | SQLException e) {
		throw new LibraryManagementException("sorry not fetching the Purchase Id");
		
	}
	//System.out.println("The list contains:" + list);
	return list;
	
}
//gettransId
public ArrayList<String> gettransId() throws LibraryManagementException{
	Connection conn=null;
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;
	ArrayList<String> list =new ArrayList<String>(); 


	try {
		conn = DBConnection.getConnection();
		preparedStatement = conn.prepareStatement(IQueryMapper.Get_transac);
		resultSet = preparedStatement.executeQuery();
//System.out.println("try");
		while (resultSet.next()) {
			//System.out.println("while");
			list.add(resultSet.getString("TRANSACTION_ID"));
			//System.out.println("return list");
		}
		
	} catch ( LibraryManagementException | SQLException e) {
		throw new LibraryManagementException("sorry not fetching the transaction Id");
		
	}
	//System.out.println("The list contains:" + list);
	return list;
	
}
public ArrayList<String> getBookfromReg() throws LibraryManagementException{
	Connection conn=null;
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;
	ArrayList<String> list =new ArrayList<String>(); 


	try {
		conn = DBConnection.getConnection();
		preparedStatement = conn.prepareStatement(IQueryMapper.bookIdregtable);
		resultSet = preparedStatement.executeQuery();
//System.out.println("try");
		while (resultSet.next()) {
			//System.out.println("while");
			list.add(resultSet.getString("Book_Id"));
			//System.out.println("return list");
		}
		
	} catch ( LibraryManagementException | SQLException e) {
		throw new LibraryManagementException("sorry not fetching the transaction Id");
		
	}
	//System.out.println("The list contains:" + list);
	return list;
	
}
public ArrayList<BooksTransactionDto> SearchMobile(String min) throws LibraryManagementException{
	
	Connection conn=null;
	PreparedStatement getsearchStmt = null;
	ResultSet searchResult = null;
	ArrayList<BooksTransactionDto> listSearch =new ArrayList<BooksTransactionDto>(); 
	try{
conn = DBConnection.getConnection();
getsearchStmt = conn.prepareStatement(IQueryMapper.Search_query);
	getsearchStmt.setString(1,min);
	//getsearchStmt.setString(2,max);
	searchResult=getsearchStmt.executeQuery();
	while(searchResult.next()){
		BooksTransactionDto m=new BooksTransactionDto();
		m.setTransaction_Id(searchResult.getString(1));
		m.setREGISTRATION_ID(searchResult.getString(2));
		m.setIssue_date(searchResult.getDate(3));
		m.setReturn_date(searchResult.getDate(4));
		m.setActualReturn_date(searchResult.getDate(5));
		m.setFine(searchResult.getDouble(6));
		listSearch.add(m);}}
		catch(SQLException e ) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			//logger.error(e.getMessage());
			//System.out.println(e);
		}
		catch(LibraryManagementException exception2){
						//logger.error(exception2.getMessage());
						System.out.println(exception2);
					}
	//System.out.println("The list contains:" + listSearch);
	return listSearch;
	

}
public ArrayList<String> getUserId() throws LibraryManagementException{
	Connection conn=null;
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;
	ArrayList<String> list =new ArrayList<String>(); 


	try {
		conn = DBConnection.getConnection();
		preparedStatement = conn.prepareStatement(IQueryMapper.userId);
		resultSet = preparedStatement.executeQuery();

		while (resultSet.next()) {
			list.add(resultSet.getString("USER_ID"));
			
		}
		
	} catch ( LibraryManagementException | SQLException e) {
		throw new LibraryManagementException("sorry not fetching the Purchase Id");
		
	}
	//System.out.println("The list contains:" + list);
	return list;
	
}
public ArrayList<String> getbookId() throws LibraryManagementException{
	Connection conn=null;
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;
	ArrayList<String> list =new ArrayList<String>(); 


	try {
		conn = DBConnection.getConnection();
		preparedStatement = conn.prepareStatement(IQueryMapper.GetBookId);
		resultSet = preparedStatement.executeQuery();

		while (resultSet.next()) {
			list.add(resultSet.getString("BOOK_ID"));
			
		}
		
	} catch ( LibraryManagementException | SQLException e) {
		throw new LibraryManagementException("sorry not fetching the Purchase Id");
		
	}
	//System.out.println("The list contains:" + list);
	return list;
	
}
//ResultSet rs = stmt.executeQuery(
//"SELECT COF_NAME, PRICE FROM COFFEES");
public String getBookReg(String idd)throws LibraryManagementException, SQLException{
	Connection conn;
	PreparedStatement getPurchseIdstmt=null;
	ResultSet regresult=null;
     String BookId="";
     BookRegistrationDto regDto=new BookRegistrationDto();
    try{
    	//System.out.println("hi");
    	//System.out.println(idd);
	conn=DBConnection.getConnection();
	getPurchseIdstmt=conn.prepareStatement(IQueryMapper.BookIdfromReg);
	//insertstmt.setString(1,traDto.getTransaction_Id());
	getPurchseIdstmt.setString(1,idd);
	//insertstmt.setString(1,regDto.getRegistration_id());
	//insertstmt.setString(1,traDto.getTransaction_Id());
	//System.out.println("hi");
	regresult=getPurchseIdstmt.executeQuery();
	while(regresult.next()){
		BooksTransactionDto m=new BooksTransactionDto();
		regDto.setBook_Id(regresult.getString(1));
		//m.setFine(searchResult.getDouble(6));
		//listSearch.add(m);
		BookId=regDto.getBook_Id();
		}}
		catch(SQLException e ) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			//logger.error(e.getMessage());
			//System.out.println(e);
		}
		catch(LibraryManagementException exception2){
						//logger.error(exception2.getMessage());
						System.out.println(exception2);
					}
	//System.out.println("The list contains:" + listSearch);
	return BookId;
	

}
public String selectAvailability(String idd)throws LibraryManagementException, SQLException{
	Connection conn;
	PreparedStatement getPurchseIdstmt=null;
	ResultSet regresult=null;
     String BookId="";
     BookInventoryDto regDto=new BookInventoryDto();
    try{
    	//System.out.println("hi");
    	//System.out.println(idd);
	conn=DBConnection.getConnection();
	getPurchseIdstmt=conn.prepareStatement(IQueryMapper.selectAvailability);
	//insertstmt.setString(1,traDto.getTransaction_Id());
	getPurchseIdstmt.setString(1,idd);
	//insertstmt.setString(1,regDto.getRegistration_id());
	//insertstmt.setString(1,traDto.getTransaction_Id());
	//System.out.println("hi");
	regresult=getPurchseIdstmt.executeQuery();
	while(regresult.next()){
		BookInventoryDto m=new BookInventoryDto();
		regDto.setAvailabiity(regresult.getString(1));
		//m.setFine(searchResult.getDouble(6));
		//listSearch.add(m);
		BookId=regDto.getAvailabiity();
		}}
		catch(SQLException e ) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			//logger.error(e.getMessage());
			//System.out.println(e);
		}
		catch(LibraryManagementException exception2){
						//logger.error(exception2.getMessage());
						System.out.println(exception2);
					}
	//System.out.println("The list contains:" + listSearch);
	return BookId;
	

}
public BookRegistrationDto updateStatusReq(BookRegistrationDto s)throws LibraryManagementException, SQLException{
	String status="";
	
	conn=DBConnection.getConnection();
	BookRegistrationDto regDto=new BookRegistrationDto();
	//BooksTransactionDto dto=new BooksTransactionDto();
	//System.out.println(conn);
	try{
		
		//System.out.println("hi");
			insertstmt=conn.prepareStatement(IQueryMapper.updateStatusReq);
			//insertstmt.setInt(1,m.getMobileId());
			insertstmt.setString(1,s.getRegistration_id());
			//insertstmt.setDate(2,aadate);
			System.out.println("hi1");
			insertstmt.executeUpdate();
			 status=regDto.getStatusreq();
			 
			// System.out.println(status);
			conn.commit();
			//insertStmt.close();
			//conn.close();
			
		//}
		
	}
	catch(SQLException| NullPointerException e)
	{
		//logger.error(e);
		throw new LibraryManagementException("Tehnical problem occured refer log");
//e.printStackTrace();

	}//finally{
		
			
		//}
		
	
	//return m;


	return s;
}
public String getRegTra(String idd)throws LibraryManagementException, SQLException{
	Connection conn;
	PreparedStatement getPurchseIdstmt=null;
	ResultSet regresult=null;
     String BookId="";
     BooksTransactionDto regDto=new BooksTransactionDto();
    try{
    	//System.out.println("hi");
    	//System.out.println(idd);
	conn=DBConnection.getConnection();
	getPurchseIdstmt=conn.prepareStatement(IQueryMapper.selectregTra);
	//insertstmt.setString(1,traDto.getTransaction_Id());
	getPurchseIdstmt.setString(1,idd);
	//insertstmt.setString(1,regDto.getRegistration_id());
	//insertstmt.setString(1,traDto.getTransaction_Id());
	//System.out.println("hi");
	regresult=getPurchseIdstmt.executeQuery();
	while(regresult.next()){
		BooksTransactionDto m=new BooksTransactionDto();
		regDto.setREGISTRATION_ID(regresult.getString(1));
		//m.setFine(searchResult.getDouble(6));
		//listSearch.add(m);
		BookId=regDto.getREGISTRATION_ID();
		}}
		catch(SQLException e ) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			//logger.error(e.getMessage());
			//System.out.println(e);
		}
		catch(LibraryManagementException exception2){
						//logger.error(exception2.getMessage());
						System.out.println(exception2);
					}
	//System.out.println("The list contains:" + listSearch);
	return BookId;
	

}

public BookInventoryDto updateAvailability(BookInventoryDto traDto)throws LibraryManagementException, SQLException{
	
	String status="";
	BookInventoryDto b=new BookInventoryDto();
	conn=DBConnection.getConnection();
	//BooksTransactionDto dto=new BooksTransactionDto();
	//System.out.println(conn);
	try{
		
		
			insertstmt=conn.prepareStatement(IQueryMapper.updateAvailability);
			//insertstmt.setInt(1,m.getMobileId());
			insertstmt.setString(1,traDto.getBook_id());
			//insertstmt.setDate(2,aadate);
			
			insertstmt.executeUpdate();
			status=b.getAvailabiity();
			//System.out.println(status);
			conn.commit();
			//insertStmt.close();
			//conn.close();
			
		//}
		
	}
	catch(SQLException| NullPointerException e)
	{
		//logger.error(e);
		throw new LibraryManagementException("Tehnical problem occured refer log");
//e.printStackTrace();

	}//finally{
		
			
		//}
		
	
	//return m;


	return traDto;
}
//issueStatus1
public BookInventoryDto updateAvailabiltyA(BookInventoryDto traDto)throws LibraryManagementException, SQLException{
	
	String status="";
	BookInventoryDto b=new BookInventoryDto();
	conn=DBConnection.getConnection();
	//BooksTransactionDto dto=new BooksTransactionDto();
	//System.out.println(conn);
	try{
		
		
			insertstmt=conn.prepareStatement(IQueryMapper.updateAvailabilityA);
			//insertstmt.setInt(1,m.getMobileId());
			insertstmt.setString(1,traDto.getBook_id());
			//insertstmt.setDate(2,aadate);
			
			insertstmt.executeUpdate();
			status=b.getAvailabiity();
			//System.out.println(status);
			conn.commit();
			//insertStmt.close();
			//conn.close();
			
		//}
		
	}
	catch(SQLException| NullPointerException e)
	{
		//logger.error(e);
		throw new LibraryManagementException("Tehnical problem occured refer log");
//e.printStackTrace();

	}//finally{
		
			
		//}
		
	
	//return m;


	return traDto;
}

public String issueStatus1(String idd)throws LibraryManagementException, SQLException{
	Connection conn;
	PreparedStatement getPurchseIdstmt=null;
	ResultSet regresult=null;
     String BookId="";
     BookRegistrationDto regDto=new BookRegistrationDto();
    try{
    	//System.out.println("hi");
    	//System.out.println(idd);
	conn=DBConnection.getConnection();
	getPurchseIdstmt=conn.prepareStatement(IQueryMapper.selectIssueStatus);
	//insertstmt.setString(1,traDto.getTransaction_Id());
	getPurchseIdstmt.setString(1,idd);
	//insertstmt.setString(1,regDto.getRegistration_id());
	//insertstmt.setString(1,traDto.getTransaction_Id());
	//System.out.println("hi");
	regresult=getPurchseIdstmt.executeQuery();
	while(regresult.next()){
		BookRegistrationDto m=new BookRegistrationDto();
		regDto.setStatusreq(regresult.getString(1));
		//m.setFine(searchResult.getDouble(6));
		//listSearch.add(m);
		BookId=regDto.getStatusreq();
		//System.out.println(BookId);
		}}
		catch(SQLException e ) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			//logger.error(e.getMessage());
			//System.out.println(e);
		}
		catch(LibraryManagementException exception2){
						//logger.error(exception2.getMessage());
						System.out.println(exception2);
					}
	//System.out.println("The list contains:" + listSearch);
	return BookId;
	

}
public String getRegBId(String idd)throws LibraryManagementException, SQLException{
	Connection conn;
	PreparedStatement getPurchseIdstmt=null;
	ResultSet regresult=null;
     String BookId="";
     BookRegistrationDto regDto=new BookRegistrationDto();
    try{
    	//System.out.println("hi");
    	//System.out.println(idd);
	conn=DBConnection.getConnection();
	getPurchseIdstmt=conn.prepareStatement(IQueryMapper.selectRegBid);
	//insertstmt.setString(1,traDto.getTransaction_Id());
	getPurchseIdstmt.setString(1,idd);
	//insertstmt.setString(1,regDto.getRegistration_id());
	//insertstmt.setString(1,traDto.getTransaction_Id());
	//System.out.println("hi");
	regresult=getPurchseIdstmt.executeQuery();
	while(regresult.next()){
		BooksTransactionDto m=new BooksTransactionDto();
		regDto.setRegistration_id(regresult.getString(1));
		//m.setFine(searchResult.getDouble(6));
		//listSearch.add(m);
		BookId=regDto.getRegistration_id();
		}}
		catch(SQLException e ) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			//logger.error(e.getMessage());
			//System.out.println(e);
		}
		catch(LibraryManagementException exception2){
						//logger.error(exception2.getMessage());
						System.out.println(exception2);
					}
	//System.out.println("The list contains:" + listSearch);
	return BookId;
	

}
public String getTidReg(String idd)throws LibraryManagementException, SQLException{
	Connection conn;
	PreparedStatement getPurchseIdstmt=null;
	ResultSet regresult=null;
     String BookId="";
     BooksTransactionDto regDto=new BooksTransactionDto();
    try{
    	//System.out.println("hi");
    	//System.out.println(idd);
	conn=DBConnection.getConnection();
	getPurchseIdstmt=conn.prepareStatement(IQueryMapper.selectTidReg);
	//insertstmt.setString(1,traDto.getTransaction_Id());
	getPurchseIdstmt.setString(1,idd);
	//insertstmt.setString(1,regDto.getRegistration_id());
	//insertstmt.setString(1,traDto.getTransaction_Id());
	//System.out.println("hi");
	System.out.println("tid");
	regresult=getPurchseIdstmt.executeQuery();
	while(regresult.next()){
		BooksTransactionDto m=new BooksTransactionDto();
		regDto.setTransaction_Id(regresult.getString(1));
		//m.setFine(searchResult.getDouble(6));
		//listSearch.add(m);
		BookId=regDto.getTransaction_Id();
		System.out.println(BookId);
		}}
		catch(SQLException e ) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			//logger.error(e.getMessage());
			//System.out.println(e);
		}
		catch(LibraryManagementException exception2){
						//logger.error(exception2.getMessage());
						System.out.println(exception2);
					}
	//System.out.println("The list contains:" + listSearch);
	return BookId;
	

}
}
