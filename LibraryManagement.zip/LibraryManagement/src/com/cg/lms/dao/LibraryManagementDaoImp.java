package com.cg.lms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;




import com.cg.lms.dto.BookInventoryDto;
import com.cg.lms.dto.BookRegistrationDto;
import com.cg.lms.dto.BooksTransactionDto;
import com.cg.lms.dto.UsersDto;
import com.cg.lms.exceptions.LibraryManagementException;
import com.cg.lms.presentation.LibraryUI;
import com.cg.lms.util.DBConnection;



public class LibraryManagementDaoImp implements ILibraryManagementDao{
	Connection conn;
	//String mobileId=null;
	PreparedStatement insertstmt=null;
String lib;
Double fine;
UsersDto userDtoObj=new UsersDto();

	public UsersDto setValues(UsersDto userDtoObj)throws LibraryManagementException{
		
		
			
		try{
			
			conn=DBConnection.getConnection();
			insertstmt=conn.prepareStatement(IQueryMapper.INSERT_QUERY);
		    //insertstmt.setInt(1,cust.getPurchaseId());
	        insertstmt.setString(1,userDtoObj.getUser_id());
	        insertstmt.setString(2,userDtoObj.getUser_name());
		    insertstmt.setString(3,userDtoObj.getPassword());
		    insertstmt.setString(4,userDtoObj.getEmail_id());
		    insertstmt.setString(5,userDtoObj.getLibrarian());
		    int result=insertstmt.executeUpdate();
		    if(result!=1){
				//logg.info("value not inserted");
				throw new LibraryManagementException("sorry!cant process your request");
			}else{
				//conn.commit();
			}
			
		}
		catch(Exception e)
		{
			
			System.out.println(e.getMessage());
			
		
			
		}
		return userDtoObj;
	}
	public UsersDto login(UsersDto userDtoObj)throws LibraryManagementException,SQLException{
		
		try{
			
			conn=DBConnection.getConnection();
			insertstmt = conn.prepareStatement(IQueryMapper.Login_QUERY);
			
			//ResultSet result=insertstmt.executeQuery();
			//PreparedStatement login = connection.prepareStatement(sqlString);
			insertstmt.setString(1,userDtoObj.getUser_id());
			insertstmt.setString(2,userDtoObj.getPassword());
			ResultSet rs = insertstmt.executeQuery();
			if( rs.next()){
		        //return true;
				System.out.println("login sucessfull");
				lib =rs.getString(1);
			//System.out.println(lib);
			    //insertstmt.setString(5,userDtoObj.getLibrarian());

			
		   } else {
		       //return false;
			   System.out.println("u have enter wrong credentials!\n please enter your Id and Password again!");
			   LibraryUI ui= new LibraryUI();
			   ui.loginPage();
			   
		   }
		    
			
		}
		catch(Exception e)
		{
			
			System.out.println(e.getMessage());
			
		
			
		}
		return userDtoObj;
	}
public String statusMethod() throws LibraryManagementException{
	System.out.println("passing lib from dao");
	return lib;
	//System.out.println("passing lib from dao");

}
public BookInventoryDto inventory(BookInventoryDto bookIDto) throws LibraryManagementException {
	try{
		
		conn=DBConnection.getConnection();
		insertstmt=conn.prepareStatement(IQueryMapper.INSERT_Inventory);
	    //insertstmt.setInt(1,cust.getPurchaseId());
        insertstmt.setString(1,bookIDto.getBook_id());
        insertstmt.setString(2,bookIDto.getBook_name());
	    insertstmt.setString(3,bookIDto.getAuthor1());
	    insertstmt.setString(4,bookIDto.getAuthor2());
	    insertstmt.setString(5,bookIDto.getPublisher());
	    insertstmt.setString(6,bookIDto.getYearOfPublication());


	    //insertstmt.setString(5,userDtoObj.getLibrarian());
	    int result=insertstmt.executeUpdate();
	    if(result!=1){
			//logg.info("value not inserted");
			throw new LibraryManagementException("sorry!cant process your request");
		}else{
			//conn.commit();
		}
		
	}
	catch(Exception e)
	{
		
		System.out.println(e.getMessage());
		
	
		
	}
	
	
	return bookIDto;
}

public ArrayList<BookInventoryDto> getDisplay()throws LibraryManagementException{
	ArrayList <BookInventoryDto> lis=new ArrayList();
	Connection conn;
	PreparedStatement pstmt=null;
	try{
		conn=DBConnection.getConnection();
		pstmt=conn.prepareStatement(IQueryMapper.display_Inventory);
		ResultSet results=pstmt.executeQuery();
		while(results.next()){
			//logg.fatal("Getting the details of all mobiles");
			BookInventoryDto dbobj=new BookInventoryDto();
			dbobj.setBook_id(results.getString(1));
			dbobj.setBook_name(results.getString(2));
			dbobj.setAuthor1(results.getString(3));
			dbobj.setAuthor2(results.getString(4));
			dbobj.setPublisher(results.getString(5));
			dbobj.setYearOfPublication(results.getString(6));
			lis.add(dbobj);
		}
	}catch(Exception e){
		System.err.println(e);
	}
	return lis;
}
public String delRecordsSql(String del) throws LibraryManagementException {
	Connection conn = DBConnection.getConnection();
	PreparedStatement preDel = null;

	try {
		preDel = conn.prepareStatement(IQueryMapper.DELETE_Records);
		preDel.setString(1, del);
		int result = preDel.executeUpdate();
		if (result != 1) {
			//logg.debug("Deletion failed ");
			throw new LibraryManagementException("Deletion failed or Id not Available");
		} else {
			System.out.println("Record deleted..!!");
			conn.close();
		}

	} catch (SQLException e) {

		e.printStackTrace();
	}
	return del;

}
public BookRegistrationDto userRequest(BookRegistrationDto regDto) throws LibraryManagementException {
	try{
		//UsersDto userdto=new UsersDto();
		conn=DBConnection.getConnection();
		insertstmt=conn.prepareStatement(IQueryMapper.INSERT_request);
	    //insertstmt.setInt(1,cust.getPurchaseId());
        insertstmt.setString(1,regDto.getBook_Id());
        insertstmt.setString(2,regDto.getUser_Id());
        int result=insertstmt.executeUpdate();
       // userDtoObj.setUser_id(result.getString("User_Id");

	    //insertstmt.setString(5,userDtoObj.getLibrarian());
	    
	    if(result!=1){
			//logg.info("value not inserted");
			throw new LibraryManagementException("sorry!cant process your request");
		}else{
			//conn.commit();
		}
		
	}
	catch(Exception e)
	{
		
		System.out.println(e.getMessage());
		
	
		
	}
	
	
	return regDto;
}
@Override
public String getRegistrationId()throws LibraryManagementException, SQLException{
	Connection conn;
	PreparedStatement getPurchseIdstmt=null;
	ResultSet regresult=null;
     String registrationId="";
    try{
	conn=DBConnection.getConnection();
	getPurchseIdstmt=conn.prepareStatement(IQueryMapper.GET_RID);
	regresult=getPurchseIdstmt.executeQuery();
	while(regresult.next()){
		registrationId=regresult.getString(1);
		//System.out.println(registrationId);
	}
}catch(Exception e){
	System.out.print(e.getMessage());
}
		
	return registrationId;
}
public ArrayList<BookRegistrationDto> getRequest()throws LibraryManagementException{
	ArrayList <BookRegistrationDto> lis=new ArrayList<BookRegistrationDto>();
	Connection conn;
	PreparedStatement pstmt=null;
	try{
		conn=DBConnection.getConnection();
		pstmt=conn.prepareStatement(IQueryMapper.See_Req);
		ResultSet results=pstmt.executeQuery();
		while(results.next()){
			//logg.fatal("Getting the details of all mobiles");
			BookRegistrationDto dbobj=new BookRegistrationDto();
			dbobj.setRegistration_id(results.getString(1));;
			dbobj.setBook_Id(results.getString(2));
			dbobj.setUser_Id(results.getString(3));
			dbobj.setRegistrationdate(results.getDate(4));
			lis.add(dbobj);
		}
	}catch(Exception e){
		System.err.println(e);
	}
	return lis;
}
public BooksTransactionDto transactionMethod(BooksTransactionDto traDto)throws LibraryManagementException,SQLException{

try{
		
		conn=DBConnection.getConnection();
		insertstmt=conn.prepareStatement(IQueryMapper.INSERT_transaction);
	    //insertstmt.setInt(1,cust.getPurchaseId());
        insertstmt.setString(1,traDto.getREGISTRATION_ID());
        
      //  insertstmt.setDate(2,traDto.getActualReturn_date());
        insertstmt.setDouble(2,traDto.getFine());
        
        
	    //insertstmt.setString(5,userDtoObj.getLibrarian());
	    int result=insertstmt.executeUpdate();
	    if(result!=1){
			//logg.info("value not inserted");
			throw new LibraryManagementException("sorry!cant process your request");
		}else{
			//conn.commit();
		}
		
	}
	catch(Exception e)
	{
		
		//System.out.println(e.getMessage());
		
	
		
	}
	
	
	return traDto;
}
@Override
public String getTransactionId() throws LibraryManagementException, SQLException{
	Connection conn;
	PreparedStatement getPurchseIdstmt=null;
	ResultSet regresult=null;
     String registrationId="";
    try{
	conn=DBConnection.getConnection();
	getPurchseIdstmt=conn.prepareStatement(IQueryMapper.GET_TID);
	regresult=getPurchseIdstmt.executeQuery();
	while(regresult.next()){
		registrationId=regresult.getString(1);
		//System.out.println(registrationId);
	}
}catch(Exception e){
	System.out.print(e.getMessage());
}
		
	return registrationId;
}
public BooksTransactionDto updateReturn(BooksTransactionDto traDto)throws LibraryManagementException, SQLException{
	
	
	conn=DBConnection.getConnection();
	//BooksTransactionDto dto=new BooksTransactionDto();
	//System.out.println(conn);
	try{
		
		//java.util.Date udate = m.getPurchaseDate();
		//java.sql.Date sdate = new java.sql.Date(udate.getTime());
		
		//insertstmt=conn.prepareStatement(IQueryMapper.INSERT_QUERY);
		//insertStmt.setInt(1,m.getPurchaseId());
		//insertstmt.setString(1,m.getCustomerName());
		////insertstmt.setString(2,m.getMailId());
		//insertstmt.setString(3,m.getPhoneNumber());
	
		//insertstmt.setDate(4,sdate);
		//insertstmt.setInt(5,m.getMobileId());
		
		//int result=insertstmt.executeUpdate();
		
		//if(result!=1){
			//logger.debug("value not inserted");
			//throw new LibraryManagementException("sorry!cant process your request");
		//}else{
			//purchaseId=getPurchaseId();
			//m.setPurchaseId(purchaseId);
			insertstmt=conn.prepareStatement(IQueryMapper.update_actualDate);
			//insertstmt.setInt(1,m.getMobileId());
			insertstmt.setString(1,traDto.getTransaction_Id());
			insertstmt.executeUpdate();
			conn.commit();
			//insertStmt.close();
			//conn.close();
			
		//}
		
	}
	catch(SQLException| NullPointerException e)
	{
		//logger.error(e);
		throw new LibraryManagementException("Tehnical problem occured refer log");
//e.printStackTrace();

	}//finally{
		
			
		//}
		
	
	//return m;


	return traDto;
}
//getFine
public BooksTransactionDto updateFine(BooksTransactionDto traDto) throws LibraryManagementException, SQLException{
	conn=DBConnection.getConnection();
	PreparedStatement pstmt=null;
	/*String query = "SELECT COF_NAME, PRICE FROM COFFEES";
	ResultSet rs = stmt.executeQuery(query);
	while (rs.next()) {
	    String s = rs.getString("COF_NAME");
	    float n = rs.getFloat("PRICE");
	    System.out.println(s + "   " + n);
		*/
	
		try{
			//String query="select return_date from bookstransaction where transaction_id =?";
			pstmt=conn.prepareStatement(IQueryMapper.selectReturnDate);
			//insertstmt.setString(1,traDto.getTransaction_Id());
			
			
	insertstmt=conn.prepareStatement(IQueryMapper.update_fine);
	insertstmt.setString(1,traDto.getTransaction_Id());
	insertstmt.executeUpdate();
	conn.commit();
		
	}
	catch(SQLException| NullPointerException e)
	{
		//logger.error(e);
		throw new LibraryManagementException("Tehnical problem occured refer log");
//e.printStackTrace();

	}//finally{
		
			
		//}
		
	
	//return m;
	
	

	return traDto;
}
	//double fine=traDto.getFine();
	//traDto.setFine(fine);
	//purchaseId=getPurchaseId();
	//m.setPurchaseId(purchaseId);
public ArrayList<BooksTransactionDto> getDisplayFine()throws LibraryManagementException{
	ArrayList <BooksTransactionDto> lis=new ArrayList();
	Connection conn;
	PreparedStatement pstmt=null;
	try{
		conn=DBConnection.getConnection();
		
		pstmt=conn.prepareStatement(IQueryMapper.display_fine);
		//insertstmt.setString(1,traDto.getTransaction_Id());
		ResultSet results=pstmt.executeQuery();
		while(results.next()){
			//logg.fatal("Getting the details of all mobiles");
			BooksTransactionDto dbobj=new BooksTransactionDto();
			dbobj.setTransaction_Id(results.getString(1));
			dbobj.setREGISTRATION_ID(results.getString(2));
			dbobj.setIssue_date(results.getDate(3));
			//dbobj.getReturn_date()
			dbobj.setReturn_date(results.getDate(4));
			dbobj.setActualReturn_date(results.getDate(5));
			dbobj.setFine(results.getDouble(6));
			
			//dbobj.setBook_name(results.getString(2));
			//dbobj.setAuthor1(results.getString(3));
			//dbobj.setAuthor2(results.getString(4));
			//dbobj.setPublisher(results.getString(5));
			//dbobj.setYearOfPublication(results.getString(6));
			lis.add(dbobj);
		}
	}catch(Exception e){
		System.err.println(e);
	}
	return lis;
}
public Double displayFine(BooksTransactionDto traDto) throws LibraryManagementException, SQLException{
	conn=DBConnection.getConnection();
	PreparedStatement insertstmt=null;
	ResultSet regresult=null;

	try{
	insertstmt=conn.prepareStatement(IQueryMapper.display_fine);
	insertstmt.setString(1,traDto.getTransaction_Id());
	 regresult = insertstmt.executeQuery();
	//purchaseId=getPurchaseId();
	//m.setPurchaseId(purchaseId);
	//fine=regresult.getDouble(1);
	//double fine=displayFine();
	//traDto.setFine(fine);
	 BooksTransactionDto dto= new BooksTransactionDto();
	 fine=dto.getFine();
	 dto.setFine(regresult.getDouble(1));
	conn.commit();
	}
	catch(SQLException| NullPointerException e)
	{
		//logger.error(e);
		throw new LibraryManagementException("Tehnical problem occured refer log");
//e.printStackTrace();

	}//finally{
		
			
		//}
		
	
	//return m;


	return fine;
}

}


