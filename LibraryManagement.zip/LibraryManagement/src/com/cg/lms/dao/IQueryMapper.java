package com.cg.lms.dao;

public interface IQueryMapper {
    public static final String INSERT_QUERY="INSERT into users values(?,?,?,?,?)";
    public static final String Login_QUERY="select librarian from  users where User_id =? AND password =?";
    public static final String display_QUERY="select user_id,password,librarian from  users" ;
    public static final String INSERT_Inventory="INSERT INTO BOOKSINVENTORY values(?,?,?,?,?,?)";
    public static final String display_Inventory="select * from BOOKSINVENTORY";
    public static final String DELETE_Records="Delete from BOOKSINVENTORY where book_id =?";
	public static final String INSERT_request = "INSERT into BOOKSREGISTRATION values(seqreq.nextval,?,?,sysdate)";

   public static final String GET_RID = "SELECT seqreq.currval from dual";
   //public static final String GET_PID = "SELECT seq3.currval from dual";
   
   public static final String See_Req="select * from BOOKSREGISTRATION";
   public static final String INSERT_transaction ="INSERT into bookstransaction  values(seqTID.nextval,?,sysdate,sysdate+14,sysdate,?)";

   public static final String GET_TID ="SELECT seqTID.currval from dual";
   public static final String update_actualDate= "update bookstransaction set actualreturn_date=sysdate where transaction_id =?";
   public static final String selectActualDate="select actualreturn_date from bookstransaction where transaction_id =?";
   public static final String selectReturnDate="select return_date from bookstransaction where transaction_id =?";

   public static final String update_fine="update bookstransaction set fine=((actualreturn_date -return_date)+1 ) where transaction_id =?";
   public static final String display_fine="select * from bookstransaction ";
   public static final String update_fine1="update bookstransaction set fine=0.0 where transaction_id =?";
   public static final String GET_RegId="select REGISTRATION_ID from BOOKSREGISTRATION";
   public static final String Get_transac="select TRANSACTION_ID from bookstransaction";
}



