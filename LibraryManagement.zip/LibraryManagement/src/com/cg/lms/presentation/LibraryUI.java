package com.cg.lms.presentation;


import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.Scanner;





import com.cg.lms.dto.BookInventoryDto;
import com.cg.lms.dto.BookRegistrationDto;
import com.cg.lms.dto.BooksTransactionDto;
import com.cg.lms.dto.UsersDto;
import com.cg.lms.exceptions.LibraryManagementException;
import com.cg.lms.service.LibraryManagementServiceImpl;



public class LibraryUI {
        private static Scanner in;
		public static void main(String[] args) throws LibraryManagementException,SQLException {
			in = new Scanner(System.in);
			System.out.println("Welcome to CapGemini Library Management System");
			String choice = "initial";
			while (!choice.equals("3")) {
				System.out.println("Enter your choice");
				System.out.println("1.New User");
				System.out.println("2.Login");
				System.out.println("3.Exit");
				choice = in.next().trim();
				switch (choice) {
				case "1":
				    getUserInputs();
				     break;
			    case "2":
				     loginPage();
				     break;
			
			    case "3":
				     System.out.println("\n Thank You!!");
				     System.exit(0);
				     break;
			    default:
				     System.out.println("Enter valid input");

	}

}
	}
		
	public static LibraryManagementServiceImpl serObj=new LibraryManagementServiceImpl();
	public static UsersDto userDtoObj=new UsersDto();
	public static BookInventoryDto bookIDto=new BookInventoryDto();
	public static BookRegistrationDto regDto=new BookRegistrationDto();
	public static BooksTransactionDto traDto=new BooksTransactionDto();

	 static String user_Id;
	 static String user_name;
	 static String password;
	 static  String email_id;
	 static String librarian;
		static String status;
		static String book_Id;
		static String book_name;
		static String author1;
		static String author2;
		static String publisher;
		static String yearOfPublication;
		static String registration_Id;
		//private String book_Id;
		//private String user_Id;
		static Date registrationdate;
		 static String transaction_Id;
		 //private String user_Id;
		 static Date issue_date;
		 static Date return_date;
		 static Date actualReturn_date;
		 
		static  double fine;
		static String availabiity;
		static String statusreq;

		public static void getUserInputs()
		
		{
			
			// String lib;
			 
			 while(true){
			 System.out.println("Enter User Id");
			 user_Id=in.next();
			 if (serObj.validateUserId(user_Id) == true) {
					break;
				} else {
					System.out.println("Enter Valid user Id  ");
				}
			 }
			 while (true) {
					System.out.println("Enter user name");
					user_name = in.next();
					if (serObj.validateUserName(user_name) == true) {
						break;
					} else {
						System.out.println("Enter Valid NAme Starting with capital letter min 7 and max 20 characters without spaces");
					}
				}
			 
			 while (true) {
					System.out.println("Enter your Password");
					password = in.next();
					if (serObj.validateUserPass(password) == true) {
						break;
					} else {
						System.out.println("Enter Valid password");
					}
				}
			 
			 while (true) {
					System.out.println("Enter your Email Id");
					email_id = in.next();
					if (serObj.validateUserEmail(email_id) == true) {
						break;
					} else {
						System.out.println("Enter Valid mail id");
					}
				}
			 
			 while (true) {
					System.out.println("Enter Y for Librarian N for Student");
					librarian = in.next();
					if (serObj.validateStatus(librarian) == true) {
						break;
					} else {
						System.out.println("Enter Valid status as Y or N");
					}
					
			}
			 
				
		userDtoObj.setUser_id(user_Id);
	
		userDtoObj.setUser_name(user_name);
		userDtoObj.setPassword(password);
		userDtoObj.setEmail_id(email_id);
		userDtoObj.setLibrarian(librarian);
		
		try {
			userDtoObj = serObj.setValues(userDtoObj);
		} catch (LibraryManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			 
		}
		public static void loginPage() throws LibraryManagementException,SQLException{
			System.out.println("enter user id");
			 user_Id=in.next();
			System.out.println("enter password");
			password = in.next();
			//System.out.println("Enter Y for Librarian N for Student");
		    //librarian = in.next();
			userDtoObj.setUser_id(user_Id);
			userDtoObj.setPassword(password);
			//userDtoObj.setLibrarian(librarian);
			try {
				userDtoObj = serObj.login(userDtoObj);
				status=serObj.statusMethod();
			} catch (LibraryManagementException e) {
				// TODO Auto-generated catch block
				//System.out.println("invalid login id");
				//oginPage();
				e.printStackTrace();
			}
			//try {
			// status=serObj.statusMethod();
				//System.out.println(status);
				if(status.equalsIgnoreCase("Y")){
					//System.out.println("if block");
					//System.out.println(status);
					//setBooksInventory();
					System.out.println("welcome! U have entered as librarian");
					String choice = "initial";
					while (!choice.equals("4")) {
						System.out.println("Enter your choice");
						//System.out.println("1.Display books present in library");
						System.out.println("1.Book Operations");
						//System.out.println("2.Insert books");
						//System.out.println("3.delete books");
						System.out.println("2.display request from students");
						//System.out.println("5.update books");
						System.out.println("3.Issue/return");
						
						
						System.out.println("4.Exit");
						choice = in.next().trim();
						switch (choice) {
						case "1":
							bookOpearations();
						     break;
					    case "2":
						    //insertBooks();
					    	displayRequest();
					    	//setBooksInventory();
						     break;
					    
					    case "3":
						    //updateBooks();
					    	//displayRequest();
					    	issueReturn();
						     break;
					   

					    case "4":
						     System.out.println("\n Thank You!!");
						    // System.exit(0);
						     break;
					    default:
						     System.out.println("Enter valid input");

			}

		}
					
					
				}
				else{
					System.out.println("Welcome! u have entered as student");
					displayBooks();
					setBooksRegistration();
					
					

				}

			//} catch (LibraryManagementException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			//}

			

		}
		public static void setBooksRegistration() throws LibraryManagementException{
			String choice = "initial";
			while (!choice.equals("3")) {
				System.out.println("Enter your choice");
				System.out.println("1.Request for books");
				System.out.println("2.display fine");
				System.out.println("3.Exit");
				choice = in.next().trim();
				switch (choice) {
				case "1":
				   requestBook();
				     break;
				case "2":
					//displayFine1();
					SearchMobile();
					     break;
			    case "3":
				     System.out.println("\n Thank You!!");
				    // System.exit(0);
				     break;
				     
			    default:
				     System.out.println("Enter valid input");

	}

}

		}

		
public static void setBooksInventory(){
	 while(true){
		 System.out.println("Enter Book Id");
		 book_Id=in.next();
		 if (serObj.validateBookId(book_Id) == true) {
				break;
			} else {
				System.out.println("Enter Valid book_Id   ");
			}
		 }
	 while(true){
		 System.out.println("Enter book_name ");
		 book_name=in.next();
		 if (serObj.validateBookName(book_name) == true) {
				break;
			} else {
				System.out.println("Enter Valid book_name   ");
			}
		 }
	 while(true){
		 System.out.println("Enter author1");
		 author1=in.next();
		 if (serObj.validateAuthor1(author1) == true) {
				break;
			} else {
				System.out.println("Enter Valid author1   ");
			}
		 }
	 while(true){
		 System.out.println("Enter author2");
		 author2=in.next();
		 if (serObj.validateAuthor2(author2) == true) {
				break;
			} else {
				System.out.println("Enter Valid author2   ");
			}
		 }
	 while(true){
		 System.out.println("Enter publisher Name");
		 publisher=in.next();
		 if (serObj.validatePublisher(publisher) == true) {
				break;
			} else {
				System.out.println("Enter Valid Publisher Name   ");
			}
		 }
	 while(true){
		 System.out.println("Enter year of publication");
		 yearOfPublication=in.next();
		 if (serObj.validateYOP(yearOfPublication) == true) {
				break;
			} else {
				System.out.println("Enter Valid Publication Year   ");
			}
		 }
	 System.out.println("set the availabilty of book");
	 availabiity=in.next();
	 
	 //System.out.println("");
	 bookIDto.setBook_id(book_Id);
	 bookIDto.setBook_name(book_name);
	 bookIDto.setAuthor1(author1);
	 bookIDto.setAuthor2(author2);
	 bookIDto.setPublisher(publisher);
	 bookIDto.setYearOfPublication(yearOfPublication);
	 bookIDto.setAvailabiity(availabiity);
	// availabiity=bookIDto.getAvailabiity();
	 
	 //System.out.println(availabiity);
	 
	 try {
		bookIDto=serObj.inventory(bookIDto);
	} catch (LibraryManagementException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 
}//getDisplayFine
//System.out.println(availabiity);
public static void displayBooks() throws LibraryManagementException{
	
		ArrayList<BookInventoryDto> list=new ArrayList<BookInventoryDto>();
		list=serObj.getDisplay();
		System.out.println("***Books Details***");
		System.out.println("BookId\t\tBookName\tAuthor1Name\t\tAuthor2name\tPublisherName\t\tYearOfPublication\tAvailability\n");
		if(list != null){
			Iterator<BookInventoryDto> i = list.iterator();
				while (i.hasNext()) {
					BookInventoryDto obj = (BookInventoryDto) i.next();
				     	System.out.print(obj.getBook_id()+"\t\t");
						System.out.print(obj.getBook_name()+"\t");
						System.out.print(obj.getAuthor1()+"\t\t");
						System.out.print(obj.getAuthor2()+"\t\t");
						System.out.print(obj.getPublisher()+"\t");
						System.out.print(obj.getYearOfPublication()+"\t\t\t");
						System.out.println(obj.getAvailabiity()+"\n");
					
					}
				} 
		 else 
		 {
		   System.out.println("There are no  books in the library");
		 }
	   }

private static void deleteBooks() throws LibraryManagementException {
	System.out.println("Enter BookId to delete");
	String del = in.next();
	String rid="";
	String tid="";
	String ridd="";
	try {
		 rid=serObj.getRegBId(del);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println("rid="+rid);
	try {
		traDto.setREGISTRATION_ID(rid);
		ridd=traDto.getREGISTRATION_ID();
		System.out.println(ridd);
		tid=serObj.getTidReg(ridd);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println(tid);
	serObj.delTransaction(tid);
	serObj.delRequest(rid);
	serObj.delRecord(del);
	//getRegBId
	//getTidReg

}



public static void requestBook(){
	
	int count = 3;

	boolean status=true;
	 while(status){
		 ArrayList<String> bookId = new ArrayList<String>();
			try {
				bookId= serObj.getbookId();
			} catch (LibraryManagementException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//System.out.println(availabiity);
			//bookIDto.setAvailabiity(availabiity);
			//String isAvail=bookIDto.getAvailabiity();
			//System.out.println(isAvail);
			//String isAvailable="isAvail"
		 System.out.println("Enter Book id");
		 book_Id=in.next();
		 String isAvail="";
		try {
			isAvail = serObj.selectAvailability(book_Id);
		} catch (LibraryManagementException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.out.println(isAvail);
		 if (serObj.validateBookId(book_Id) == true) {
			 if(bookId.contains(book_Id)){
				 if (serObj.validateAvailabilty(isAvail) == true) {
				// traDto.setREGISTRATION_ID(registration_Id);
				 regDto.setBook_Id(book_Id);
				regDto.setBook_Id(book_Id);
				String id=userDtoObj.getUser_id();
				regDto.setUser_Id(id);
				statusreq="requested";
				regDto.setStatusreq(statusreq);
				
				try {
					regDto=serObj.userRequest(regDto);
				} catch (LibraryManagementException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					registration_Id = serObj.getRegistrationId();
				} catch (LibraryManagementException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("Registration id is:"+registration_Id);
				regDto.setRegistration_id(registration_Id);
				break;
				 }else{
					 System.out.println("book is not available");
					 try {
						setBooksRegistration();
					} catch (LibraryManagementException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				 }
			 }else{
				 System.out.println("enter the book id from list");
			 }} else {
				System.out.println("Enter Valid BookId");
			}
		 }
	
		 //while(true){
			// System.out.println("Enter user id");
			// user_Id=in.next();
			// if (serObj.validateUserId(user_Id) == true) {
					//break;
				//} else {
				//	System.out.println("Enter Valid user");
				//}
			 //}
			 
	//regDto.setRegistration_id(registration_Id);
	
}
public static void transaction() throws LibraryManagementException, SQLException{
	int count = 3;

	boolean status=true;
	while (status) {
	ArrayList<String> registerId = new ArrayList<String>();
	try {
		registerId= serObj.getregId();
	} catch (LibraryManagementException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	displayRequest();
	//System.out.println("available register  IDs:are " +registerId);
	
		 System.out.println("Enter registration id");
		 registration_Id=in.next();
		 String issueStatus=serObj.issueStatus1(registration_Id);
		 //System.out.println(issueStatus);
		 //Date date1=new Date(issue_date);
		 SimpleDateFormat formatter = new SimpleDateFormat("dd/MMM/yy ");  
		    Date issue_date = new Date();  
		    //System.out.println(formatter.format(issue_date));  
		    //return_date.AddDays(issue_date, 14)  ;
		   // Date return_date =  issue_date.plusDays(14);
		  
		    Date return_date = addDays(issue_date,14);
		    // System.out.println(return_date);
			//System.out.println("Java Date after adding 14 days: "+return_date.toString());
		    //SimpleDateFormat formatter = new SimpleDateFormat("dd/MMM/yy ");  
		    Date actualReturn_date = new Date();  
		    //System.out.println(formatter.format(actualReturn_date)); 
		 if (serObj.validateregistration_Id(registration_Id) == true) {
			 if(registerId.contains(registration_Id)){
				 if(serObj.validateIssueStatus(issueStatus)== true)
				{
				 fine=0.0;
					//traDto.setActualReturn_date(actualReturn_date);
					//fine=in.nextDouble();
					//regDto.setRegistration_id(registration_Id);
					traDto.setREGISTRATION_ID(registration_Id);
					traDto.setFine(fine);
					traDto.setIssue_date(issue_date);
					traDto.setReturn_date(return_date);
					traDto.setActualReturn_date(actualReturn_date);
					//serObj.delRequest(registration_Id);
					
						try {
							traDto=serObj.transactionMethod(traDto);
						} catch (LibraryManagementException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
							try {
								
								transaction_Id = serObj.getTransactionId();
								System.out.println("transaction id= "+transaction_Id);
								traDto.setTransaction_Id(transaction_Id);
								
								
							} catch (LibraryManagementException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (SQLException e) {
								// TODO Auto-generated catch block
								//e.printStackTrace();
							
							}
							//String idd=regDto.getRegistration_id();
							System.out.println("registration_Id="+registration_Id);
							String bookidreg=serObj.getBookReg(registration_Id);
							//System.out.println(bookidreg);
							regDto.setRegistration_id(registration_Id);
							bookIDto.setBook_id(bookidreg);
							
							regDto=serObj.updateStatusReq(regDto);
							bookIDto=serObj.updateAvailability(bookIDto);
							//System.out.println(req);
						//	System.out.println("id="+bookidreg);
							//serObj.delRecord(id);
							
							//deleteR();
							//try{
								//String del=registration_Id;
								//serObj.delRequest(del);

							//} catch (LibraryManagementException e) {
								// TODO Auto-generated catch block
								//e.printStackTrace();
							//}
				}else{
					System.out.println("book is already issued");
					issueReturn();
				}
				break;
				}
				else
				{
					System.out.println("Enter only valid registration  ids from th list");
				}
				//break;
			} else {
				System.out.println("Enter Valid registration_Id");
				count--;
				if(count == 0)
					status = false;
			}
		}
	
	

		 
}
public static Date addDays(Date date, int days) {
	GregorianCalendar cal = new GregorianCalendar();
	cal.setTime(date);
	cal.add(Calendar.DATE, days);
			
	return cal.getTime();
}

public static void displayRequest(){
	ArrayList<BookRegistrationDto> list=new ArrayList<BookRegistrationDto>();
	try {
		list=serObj.getRequest();
	} catch (LibraryManagementException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println("***Request Details***");
	System.out.println("RegistrationId\tBookId\tUserId\t\tRegistrationDate\tStatus");
	if(list != null){
		Iterator<BookRegistrationDto> i = list.iterator();
			while (i.hasNext()) {
				BookRegistrationDto obj = (BookRegistrationDto) i.next();
				
			     	System.out.print(obj.getRegistration_id()+"\t\t");
					System.out.print(obj.getBook_Id()+"\t");
					System.out.print(obj.getUser_Id()+"\t\t");
					System.out.print(obj.getRegistrationdate()+"\t\t");
					System.out.println(obj.getStatusreq()+"\n");
					
				}
			} 
	 else 
	 {
	   System.out.println("There are no  requests ");
	 }
	//minRequest();
   }

public static void returnBook(){
	int count = 3;

	boolean status=true;
	while (status) {
	ArrayList<String> transactionId = new ArrayList<String>();
	try {
		transactionId= serObj.gettransId();
	} catch (LibraryManagementException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	System.out.println("available transaction   IDs:are " +transactionId);
	System.out.println("enter the transaction id");
	transaction_Id=in.next();
	//SimpleDateFormat formatter = new SimpleDateFormat("dd/MMM/yy ");
	 // actualReturn_date = new Date();  
	  //  System.out.println(formatter.format(actualReturn_date)); 
	    
	 if (serObj.validatetransaction_Id(transaction_Id) == true) {
	if(transactionId.contains(transaction_Id)){
		
	System.out.println("return updated date");
	traDto.setTransaction_Id(transaction_Id);
	//traDto.setActualReturn_date(actualReturn_date);
	try {
		traDto=serObj.updateReturn(traDto);
	} catch (LibraryManagementException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println("actual return date updated as todays date");
	//transaction_Id
	String reg="";
	String bookIdreg="";
	try {
		reg = serObj.getRegTra(transaction_Id);
	} catch (LibraryManagementException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println(reg);
	//String bookIdreg;
	try {
		bookIdreg = serObj.getBookReg(reg);
	} catch (LibraryManagementException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println(bookIdreg);
	bookIDto.setBook_id(bookIdreg);
	bookIDto.getBook_id();
	try {
		bookIDto=serObj.updateAvailabiltyA(bookIDto);
	} catch (LibraryManagementException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
break;
	}
	else
	{
		System.out.println("Enter only valid transaction  ids from th list");
	}
	//break;
} else {
	System.out.println("Enter Valid transactionId");
	count--;
	if(count == 0)
		status = false;
}}
}
	
public static void updateFine(){
	
	int count = 3;

	boolean status=true;
	while (status) {
	ArrayList<String> transactionId = new ArrayList<String>();
	try {
		transactionId= serObj.gettransId();
	} catch (LibraryManagementException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	System.out.println("available transaction   IDs:are " +transactionId);
	System.out.println("enter the transaction id");
	transaction_Id=in.next();
	 if (serObj.validatetransaction_Id(transaction_Id) == true) {
	if(transactionId.contains(transaction_Id)){
		
	
	traDto.setTransaction_Id(transaction_Id);
	//if(actualReturn_date.compareTo(return_date)>0){
	try {
		traDto = serObj.updateFine(traDto);
	} catch (LibraryManagementException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println("fine is updated");
	break;
//	}else{
		//fine=0;
	//}
	}
	else
	{
		System.out.println("Enter only valid transaction  ids from th list");
	}
	//break;
} else {
	System.out.println("Enter Valid transactionId");
	count--;
	if(count == 0)
		status = false;
}}
}

public static void bookOpearations()throws LibraryManagementException{
	
		//System.out.println("if block");
		//System.out.println(status);
		//setBooksInventory();
		System.out.println("welcome! U have entered as librarian");
		String choice = "initial";
		while (!choice.equals("5")) {
			System.out.println("Enter your choice");
			System.out.println("1.Display books present in library");
			
			System.out.println("2.Insert books");
			System.out.println("3.delete books");
			//System.out.println("4.display request from students");
			System.out.println("4.update books");
			
			
			System.out.println("5.Exit");
			choice = in.next().trim();
			switch (choice) {
			case "1":
			    displayBooks();
			     break;
		    case "2":
			    //insertBooks();
		    	//bookOpearations();
		    	setBooksInventory();
			     break;
		    case "3":
			    deleteBooks();
			     break;
		    case "4":
			   // updateBooks();
		    	//displayRequest();
			     break;
		  

		    case "5":
			     System.out.println("\n Thank You!!");
			    // System.exit(0);
			     break;
		    default:
			     System.out.println("Enter valid input");
			}
		}
}
public static void issueReturn() throws SQLException{
	String choice = "initial";
	while (!choice.equals("5")) {
		System.out.println("Enter your choice");
		//System.out.println("1.Display books present in library");
		
		//System.out.println("2.Insert books");
		//System.out.println("3.delete books");
		//System.out.println("4.display request from students");
		//System.out.println("4.update books");
		
		System.out.println("1.Issue book");
		System.out.println("2.return book transaction");
		System.out.println("3.calculate fine");
		System.out.println("4.display fine");
		
		System.out.println("5.Exit");
		choice = in.next().trim();
		switch (choice) {
		case "1":
			try {
				transaction();
			} catch (LibraryManagementException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		     break;
	    case "2":
		    
	    	returnBook();
		     break;
	    case "3":
	    	updateFine();
		     break;
	    case "4":
		   
	    	try {
				//displayFine1();
	    		SearchMobile();
			} catch (LibraryManagementException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		     break;
	 
	    case "5":
		     System.out.println("\n Thank You!!");
		    // System.exit(0);
		     break;
	    default:
		     System.out.println("Enter valid input");
		}
	}
	
}
public static void SearchMobile() throws LibraryManagementException{
		int count = 3;

	boolean status=true;
	while (status) {
	ArrayList<String> transactionId = new ArrayList<String>();
	try {
		transactionId= serObj.gettransId();
	} catch (LibraryManagementException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	System.out.println("available transaction   IDs:are " +transactionId);

	System.out.println("enter tid");
	 transaction_Id=in.next();
	 if (serObj.validatetransaction_Id(transaction_Id) == true) {
			if(transactionId.contains(transaction_Id)){
	ArrayList<BooksTransactionDto> mobile = new ArrayList<BooksTransactionDto>();
	mobile = serObj.SearchMobile(transaction_Id);
	System.out.println("Search Result");
	if(mobile != null){
		Iterator<BooksTransactionDto> itr = mobile.iterator();
		while(itr.hasNext()){
			BooksTransactionDto mob = (BooksTransactionDto)itr.next();
		//System.out.println(mob.getMobileId());
			System.out.println("TransactionId\tRegistrationId\tIssueDate\tReturnDate\tActualReturnDate\tfine\n"+mob.getTransaction_Id()+"\t\t"+mob.getREGISTRATION_ID()+"\t\t"+mob.getIssue_date()+"\t"+mob.getReturn_date()+"\t"+mob.getActualReturn_date()+"\t\t"+mob.getFine());
		//System.out.println("mobile id "+mob.getMobileId()+"  name "+mob.getName()+"  price "+mob.getPrice()+"  quantity "+mob.getQuantity());
/*
		System.out.println(mob.getName());
		System.out.println(mob.getPrice());
		System.out.println(mob.getQuantity());*/
	}}else{
		System.out.println("There are no such record in the store");
		

}break;
//	}else{
		//fine=0;
	//}
	}
	else
	{
		System.out.println("Enter only valid transaction  ids from th list");
	}
	//break;
} else {
	System.out.println("Enter Valid transactionId");
	count--;
	if(count == 0)
		status = false;
}}
	}
}
	




		
		
		
	
