package com.cg.lms.presentation;

import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.cg.lms.dto.BookInventoryDto;
import com.cg.lms.dto.BookRegistrationDto;
import com.cg.lms.dto.BooksTransactionDto;
import com.cg.lms.dto.UsersDto;
import com.cg.lms.exceptions.LibraryManagementException;
import com.cg.lms.service.LibraryManagementServiceImpl;



public class LibraryUI {
        private static Scanner in;
		public static void main(String[] args) throws LibraryManagementException,SQLException {
			in = new Scanner(System.in);
			System.out.println("Welcome to CapGemini Library Management System");
			String choice = "initial";
			while (!choice.equals("3")) {
				System.out.println("Enter your choice");
				System.out.println("1.New User");
				System.out.println("2.Login");
				System.out.println("3.Exit");
				choice = in.next().trim();
				switch (choice) {
				case "1":
				    getUserInputs();
				     break;
			    case "2":
				     loginPage();
				     break;
			
			    case "3":
				     System.out.println("\n Thank You!!");
				     System.exit(0);
				     break;
			    default:
				     System.out.println("Enter valid input");

	}

}
	}
		
	public static LibraryManagementServiceImpl serObj=new LibraryManagementServiceImpl();
	public static UsersDto userDtoObj=new UsersDto();
	public static BookInventoryDto bookIDto=new BookInventoryDto();
	public static BookRegistrationDto regDto=new BookRegistrationDto();
	public static BooksTransactionDto traDto=new BooksTransactionDto();

	 static String user_Id;
	 static String user_name;
	 static String password;
	 static  String email_id;
	 static String librarian;
		static String status;
		static String book_Id;
		static String book_name;
		static String author1;
		static String author2;
		static String publisher;
		static String yearOfPublication;
		static String registration_Id;
		//private String book_Id;
		//private String user_Id;
		static Date registrationdate;
		 static String transaction_Id;
		//private String user_Id;
		 Date issue_date;
		 Date return_date;
		 static Date actualReturn_date;
		 
		static  double fine;

		public static void getUserInputs()
		
		{
			
			// String lib;
			 
			 while(true){
			 System.out.println("Enter User Id");
			 user_Id=in.next();
			 if (serObj.validateUserId(user_Id) == true) {
					break;
				} else {
					System.out.println("Enter Valid user Id  ");
				}
			 }
			 while (true) {
					System.out.println("Enter user name");
					user_name = in.next();
					if (serObj.validateUserName(user_name) == true) {
						break;
					} else {
						System.out.println("Enter Valid NAme Starting with capital letter min 7 and max 20 characters without spaces");
					}
				}
			 
			 while (true) {
					System.out.println("Enter your Password");
					password = in.next();
					if (serObj.validateUserPass(password) == true) {
						break;
					} else {
						System.out.println("Enter Valid password");
					}
				}
			 
			 while (true) {
					System.out.println("Enter your Email Id");
					email_id = in.next();
					if (serObj.validateUserEmail(email_id) == true) {
						break;
					} else {
						System.out.println("Enter Valid mail id");
					}
				}
			 
			 while (true) {
					System.out.println("Enter Y for Librarian N for Student");
					librarian = in.next();
					if (serObj.validateStatus(librarian) == true) {
						break;
					} else {
						System.out.println("Enter Valid status as Y or N");
					}
					
			}
			 
				
		userDtoObj.setUser_id(user_Id);
	
		userDtoObj.setUser_name(user_name);
		userDtoObj.setPassword(password);
		userDtoObj.setEmail_id(email_id);
		userDtoObj.setLibrarian(librarian);
		
		try {
			userDtoObj = serObj.setValues(userDtoObj);
		} catch (LibraryManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			 
		}
		public static void loginPage() throws LibraryManagementException,SQLException{
			System.out.println("enter user id");
			 user_Id=in.next();
			System.out.println("enter password");
			password = in.next();
			//System.out.println("Enter Y for Librarian N for Student");
		    //librarian = in.next();
			userDtoObj.setUser_id(user_Id);
			userDtoObj.setPassword(password);
			//userDtoObj.setLibrarian(librarian);
			try {
				userDtoObj = serObj.login(userDtoObj);
				status=serObj.statusMethod();
			} catch (LibraryManagementException e) {
				// TODO Auto-generated catch block
				//System.out.println("invalid login id");
				//oginPage();
				e.printStackTrace();
			}
			//try {
			// status=serObj.statusMethod();
				//System.out.println(status);
				if(status.equalsIgnoreCase("Y")){
					//System.out.println("if block");
					//System.out.println(status);
					//setBooksInventory();
					System.out.println("welcome! U have entered as librarian");
					String choice = "initial";
					while (!choice.equals("4")) {
						System.out.println("Enter your choice");
						//System.out.println("1.Display books present in library");
						System.out.println("1.Book Operations");
						//System.out.println("2.Insert books");
						//System.out.println("3.delete books");
						System.out.println("2.display request from students");
						//System.out.println("5.update books");
						System.out.println("3.Issue/return");
						
						
						System.out.println("4.Exit");
						choice = in.next().trim();
						switch (choice) {
						case "1":
							bookOpearations();
						     break;
					    case "2":
						    //insertBooks();
					    	displayRequest();
					    	//setBooksInventory();
						     break;
					    
					    case "3":
						    //updateBooks();
					    	//displayRequest();
					    	issueReturn();
						     break;
					   

					    case "4":
						     System.out.println("\n Thank You!!");
						    // System.exit(0);
						     break;
					    default:
						     System.out.println("Enter valid input");

			}

		}
					
					
				}
				else{
					System.out.println("Welcome! u have entered as student");
					displayBooks();
					setBooksRegistration();
					
					

				}

			//} catch (LibraryManagementException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			//}

			

		}
		public static void setBooksRegistration() throws LibraryManagementException{
			String choice = "initial";
			while (!choice.equals("3")) {
				System.out.println("Enter your choice");
				System.out.println("1.Request for books");
				System.out.println("2.display fine");
				System.out.println("3.Exit");
				choice = in.next().trim();
				switch (choice) {
				case "1":
				   requestBook();
				     break;
				case "2":
					displayFine1();
					     break;
			    case "3":
				     System.out.println("\n Thank You!!");
				    // System.exit(0);
				     break;
				     
			    default:
				     System.out.println("Enter valid input");

	}

}

		}

		
public static void setBooksInventory(){
	 while(true){
		 System.out.println("Enter Book Id");
		 book_Id=in.next();
		 if (serObj.validateBookId(book_Id) == true) {
				break;
			} else {
				System.out.println("Enter Valid book_Id   ");
			}
		 }
	 while(true){
		 System.out.println("Enter book_name ");
		 book_name=in.next();
		 if (serObj.validateBookName(book_name) == true) {
				break;
			} else {
				System.out.println("Enter Valid book_name   ");
			}
		 }
	 while(true){
		 System.out.println("Enter author1");
		 author1=in.next();
		 if (serObj.validateAuthor1(author1) == true) {
				break;
			} else {
				System.out.println("Enter Valid author1   ");
			}
		 }
	 while(true){
		 System.out.println("Enter author2");
		 author2=in.next();
		 if (serObj.validateAuthor2(author2) == true) {
				break;
			} else {
				System.out.println("Enter Valid author2   ");
			}
		 }
	 while(true){
		 System.out.println("Enter publisher Name");
		 publisher=in.next();
		 if (serObj.validatePublisher(publisher) == true) {
				break;
			} else {
				System.out.println("Enter Valid Publisher Name   ");
			}
		 }
	 while(true){
		 System.out.println("Enter year of publication");
		 yearOfPublication=in.next();
		 if (serObj.validateYOP(yearOfPublication) == true) {
				break;
			} else {
				System.out.println("Enter Valid Publication Year   ");
			}
		 }
	 bookIDto.setBook_id(book_Id);
	 bookIDto.setBook_name(book_name);
	 bookIDto.setAuthor1(author1);
	 bookIDto.setAuthor2(author2);
	 bookIDto.setPublisher(publisher);
	 bookIDto.setYearOfPublication(yearOfPublication);
	 try {
		bookIDto=serObj.inventory(bookIDto);
	} catch (LibraryManagementException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}//getDisplayFine
public static void displayBooks() throws LibraryManagementException{
	
		ArrayList<BookInventoryDto> list=new ArrayList<BookInventoryDto>();
		list=serObj.getDisplay();
		System.out.println("***Books Details***");
		if(list != null){
			Iterator<BookInventoryDto> i = list.iterator();
				while (i.hasNext()) {
					BookInventoryDto obj = (BookInventoryDto) i.next();
				     	System.out.print(obj.getBook_id()+"\t\t");
						System.out.print(obj.getBook_name()+"\t");
						System.out.print(obj.getAuthor1()+"\t\t");
						System.out.print(obj.getAuthor2()+"\t\t");
						System.out.print(obj.getPublisher()+"\t");
						System.out.print(obj.getYearOfPublication()+"\t\n");
					}
				} 
		 else 
		 {
		   System.out.println("There are no  books in the library");
		 }
	   }

private static void deleteBooks() throws LibraryManagementException {
	System.out.println("Enter BookId to delete");
	String del = in.next();
	serObj.delRecord(del);

}
public static void requestBook(){
	 while(true){
		 System.out.println("Enter Book id");
		 book_Id=in.next();
		 if (serObj.validateBookId(book_Id) == true) {
				break;
			} else {
				System.out.println("Enter Valid BookId");
			}
		 }
	
		 //while(true){
			// System.out.println("Enter user id");
			// user_Id=in.next();
			// if (serObj.validateUserId(user_Id) == true) {
					//break;
				//} else {
				//	System.out.println("Enter Valid user");
				//}
			 //}
			 
	//regDto.setRegistration_id(registration_Id);
	regDto.setBook_Id(book_Id);
	String id=userDtoObj.getUser_id();
	regDto.setUser_Id(id);
	//regDto.setRegistrationdate(registrationdate);
	try {
		regDto=serObj.userRequest(regDto);
	} catch (LibraryManagementException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		registration_Id = serObj.getRegistrationId();
	} catch (LibraryManagementException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println("Registration id is:"+registration_Id);
	regDto.setRegistration_id(registration_Id);
}
public static void transaction(){
	//String registration_Idd;
	//String idd=regDto.getRegistration_id();
	//traDto.setREGISTRATION_ID(idd);
	while(true){
		 System.out.println("Enter registration id");
		 registration_Id=in.next();
		 if (serObj.validateregistration_Id(registration_Id) == true) {
				break;
			} else {
				System.out.println("Enter Valid registration_Id");
			}
		}
	
	//System.out.println("enter default fine");
	fine=0.0;
	//traDto.setActualReturn_date(actualReturn_date);
	//fine=in.nextDouble();
	//regDto.setRegistration_id(registration_Id);
	traDto.setREGISTRATION_ID(registration_Id);
	traDto.setFine(fine);
	
		try {
			traDto=serObj.transactionMethod(traDto);
		} catch (LibraryManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			try {
				
				transaction_Id = serObj.getTransactionId();
				System.out.println("transaction id= "+transaction_Id);
				
				
			} catch (LibraryManagementException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			
			}
		//if(traDto.setREGISTRATION_ID(registration_Id);)

		 
}

public static void displayRequest(){
	ArrayList<BookRegistrationDto> list=new ArrayList<BookRegistrationDto>();
	try {
		list=serObj.getRequest();
	} catch (LibraryManagementException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println("***Request Details***");
	if(list != null){
		Iterator<BookRegistrationDto> i = list.iterator();
			while (i.hasNext()) {
				BookRegistrationDto obj = (BookRegistrationDto) i.next();
			     	System.out.print(obj.getRegistration_id()+"\t\t");
					System.out.print(obj.getBook_Id()+"\t");
					System.out.print(obj.getUser_Id()+"\t\t");
					System.out.print(obj.getRegistrationdate()+"\t\t\n");
					
				}
			} 
	 else 
	 {
	   System.out.println("There are no  requests ");
	 }
   }

public static void returnBook(){
	System.out.println("enter the transaction id");
	transaction_Id=in.next();
	traDto.setTransaction_Id(transaction_Id);
	try {
		traDto=serObj.updateReturn(traDto);
	} catch (LibraryManagementException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println("actual return date updated as todays date");
}
public static void updateFine(){
	
	System.out.println("enter the transaction id");
	transaction_Id=in.next();
	traDto.setTransaction_Id(transaction_Id);
	try {
		traDto = serObj.updateFine(traDto);
	} catch (LibraryManagementException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println("fine is updated");
}
public static void displayFineS(){
	System.out.println("enter the transaction id");
	transaction_Id=in.next();
	traDto.setTransaction_Id(transaction_Id);
	try {
		fine = serObj.displayFine(traDto);
	} catch (LibraryManagementException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println("fine= "+fine);
	//BooksTransactionDto obj = (BooksTransactionDto)
	//registration_Id = serObj.getRegistrationId();
	//System.out.print(traDto.getFine()+"\t\n");
	//registration_Id = serObj.getRegistrationId();
}
public static void displayFine1() throws LibraryManagementException{
	//System.out.println("enter the transaction id");
	//transaction_Id=in.next();
	//traDto.setTransaction_Id(transaction_Id);
	
	ArrayList<BooksTransactionDto> list=new ArrayList<BooksTransactionDto>();
	list=serObj.getDisplayFine();
	System.out.println("***Fine details***");
	if(list != null){
		Iterator<BooksTransactionDto> i = list.iterator();
			while (i.hasNext()) {
				BooksTransactionDto obj = (BooksTransactionDto) i.next();
			     	System.out.print(obj.getTransaction_Id()+"\t\t");
					System.out.print(obj.getREGISTRATION_ID()+"\t");
					System.out.print(obj.getIssue_date()+"\t\t");
					System.out.print(obj.getReturn_date()+"\t\t");
					System.out.print(obj.getActualReturn_date()+"\t");
					System.out.print(obj.getFine()+"\t\n");
				}
			} 
	 else 
	 {
	   System.out.println("There are no  books in the library");
	 }
}
public static void bookOpearations()throws LibraryManagementException{
	
		//System.out.println("if block");
		//System.out.println(status);
		//setBooksInventory();
		System.out.println("welcome! U have entered as librarian");
		String choice = "initial";
		while (!choice.equals("5")) {
			System.out.println("Enter your choice");
			System.out.println("1.Display books present in library");
			
			System.out.println("2.Insert books");
			System.out.println("3.delete books");
			//System.out.println("4.display request from students");
			System.out.println("4.update books");
			
			
			System.out.println("5.Exit");
			choice = in.next().trim();
			switch (choice) {
			case "1":
			    displayBooks();
			     break;
		    case "2":
			    //insertBooks();
		    	//bookOpearations();
		    	setBooksInventory();
			     break;
		    case "3":
			    deleteBooks();
			     break;
		    case "4":
			   // updateBooks();
		    	//displayRequest();
			     break;
		  

		    case "5":
			     System.out.println("\n Thank You!!");
			    // System.exit(0);
			     break;
		    default:
			     System.out.println("Enter valid input");
			}
		}
}
public static void issueReturn(){
	String choice = "initial";
	while (!choice.equals("5")) {
		System.out.println("Enter your choice");
		//System.out.println("1.Display books present in library");
		
		//System.out.println("2.Insert books");
		//System.out.println("3.delete books");
		//System.out.println("4.display request from students");
		//System.out.println("4.update books");
		
		System.out.println("1.Issue book");
		System.out.println("2.return book transaction");
		System.out.println("3.calculate fine");
		System.out.println("4.display fine");
		
		System.out.println("5.Exit");
		choice = in.next().trim();
		switch (choice) {
		case "1":
			transaction();
		     break;
	    case "2":
		    
	    	returnBook();
		     break;
	    case "3":
	    	updateFine();
		     break;
	    case "4":
		   
	    	try {
				displayFine1();
			} catch (LibraryManagementException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		     break;
	 
	    case "5":
		     System.out.println("\n Thank You!!");
		    // System.exit(0);
		     break;
	    default:
		     System.out.println("Enter valid input");
		}
	}
	
}
}
	




		
		
		
	
