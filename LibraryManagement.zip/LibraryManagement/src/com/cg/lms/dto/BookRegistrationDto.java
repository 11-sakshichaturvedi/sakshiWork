package com.cg.lms.dto;

import java.sql.Date;

public class BookRegistrationDto {
	private String registration_Id;
	private String book_Id;
	private String user_Id;
    private Date registrationdate;
    private String statusreq;
	public String getStatusreq() {
		return statusreq;
	}
	public void setStatusreq(String statusreq) {
		this.statusreq = statusreq;
	}
	public String getRegistration_id() {
		return registration_Id;
	}
	public void setRegistration_id(String registration_id) {
		this.registration_Id = registration_id;
	}
	public String getBook_Id() {
		return book_Id;
	}
	public void setBook_Id(String book_Id) {
		this.book_Id = book_Id;
	}
	public String getUser_Id() {
		return user_Id;
	}
	public void setUser_Id(String user_Id) {
		this.user_Id = user_Id;
	}
	public Date getRegistrationdate() {
		return registrationdate;
	}
	public void setRegistrationdate(Date registrationdate) {
		this.registrationdate = registrationdate;
	}
	
}
