package com.cg.lms.dto;

import java.sql.Date;

public class BooksTransactionDto {

	private String transaction_Id;
	private String registration_Id;
	public String getREGISTRATION_ID() {
		return registration_Id;
	}
	public void setREGISTRATION_ID(String rEGISTRATION_ID) {
		this.registration_Id = rEGISTRATION_ID;
	}
	private Date issue_date;
	private Date return_date;
	private Date actualReturn_date;
	private double fine;
	
	public String getTransaction_Id() {
		return transaction_Id;
	}
	public void setTransaction_Id(String transaction_Id) {
		this.transaction_Id = transaction_Id;
	}
	
	
	public Date getIssue_date() {
		return issue_date;
	}
	public void setIssue_date(Date issue_date) {
		this.issue_date = issue_date;
	}
	public Date getReturn_date() {
		return return_date;
	}
	public void setReturn_date(Date return_date) {
		this.return_date = return_date;
	}
	public Date getActualReturn_date() {
		return actualReturn_date;
	}
	public void setActualReturn_date(Date actualReturn_date) {
		this.actualReturn_date = actualReturn_date;
	}
	public double getFine() {
		return fine;
	}
	public void setFine(double fine) {
		this.fine = fine;
	}
	
	
}
