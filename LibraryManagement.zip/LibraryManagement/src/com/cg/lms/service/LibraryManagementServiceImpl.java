package com.cg.lms.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Pattern;


import com.cg.lms.dao.LibraryManagementDaoImp;
import com.cg.lms.dto.BookInventoryDto;
import com.cg.lms.dto.BookRegistrationDto;
import com.cg.lms.dto.BooksTransactionDto;
import com.cg.lms.dto.UsersDto;
import com.cg.lms.exceptions.LibraryManagementException;


public class LibraryManagementServiceImpl implements ILibraryManagementService {
	LibraryManagementDaoImp dao;
//public  MobileServiceImpl(){
		//
		//dao1= new MobilePurchaseDaoImp();
		
	//}
	public LibraryManagementServiceImpl(){
		dao=new LibraryManagementDaoImp();
	}
	//LibraryManagementDaoImp dao=new LibraryManagementDaoImp();
	public UsersDto login(UsersDto userDtoObj)throws LibraryManagementException,SQLException{
		return dao.login(userDtoObj);

	}
	
	public BooksTransactionDto transactionMethod(BooksTransactionDto traDto)throws LibraryManagementException,SQLException{
		return dao.transactionMethod(traDto);
	}
	 public String getTransactionId() throws LibraryManagementException, SQLException{
		 return dao.getTransactionId();
	 }
	 public BooksTransactionDto updateReturn(BooksTransactionDto traDto)throws LibraryManagementException, SQLException{
		 return dao.updateReturn(traDto);
	 }
	 public BooksTransactionDto updateFine(BooksTransactionDto traDto) throws LibraryManagementException, SQLException{
		 return dao.updateFine(traDto);
	 }

	public UsersDto setValues(UsersDto userDtoObj)throws LibraryManagementException{
		return dao.setValues(userDtoObj);
	}
	public String statusMethod() throws LibraryManagementException{
		System.out.println("service lib from dao");

		return dao.statusMethod();

	}
	public BookInventoryDto inventory(BookInventoryDto bookIDto) throws LibraryManagementException {
		return dao.inventory(bookIDto);

	}
	@Override 
    public ArrayList<BookInventoryDto> getDisplay()throws LibraryManagementException{
     return dao.getDisplay();
   }
	@Override 
	public ArrayList<BooksTransactionDto> getDisplayFine()throws LibraryManagementException{
		return dao.getDisplayFine();
	}
	@Override 
    public ArrayList<BookRegistrationDto> getRequest()throws LibraryManagementException{
     return dao.getRequest();
   }
	//getRequest
	@Override
	public void delRecord(String del) throws LibraryManagementException {
	dao.delRecordsSql(del);
	}

	
	public BookRegistrationDto userRequest(BookRegistrationDto regDto) throws LibraryManagementException {
		return dao.userRequest(regDto);
	}
	@Override
    public String getRegistrationId()throws LibraryManagementException, SQLException{
    	return dao.getRegistrationId();
    }
	public Double displayFine(BooksTransactionDto traDto) throws LibraryManagementException, SQLException{
		return dao.displayFine(traDto);
	}
	public boolean validateUserId(String userId){
    	if(Pattern.matches("\\d{4}",userId))
    	{
    	return true;
    	}
    	else
    	{
    		return false;
    	}
	}
	public boolean validateUserName(String name){
    	if(Pattern.matches("[A-Z][a-z ]{6,15}",name))
    	{
    	return true;
    	}
    	else
    	{
    		return false;
    	}
    }
	public boolean validateUserPass(String password){
    	if(Pattern.matches("[A-Za-z0-9]{7}",password))
    	{
    	return true;
    	}
    	else
    	{
    		return false;
    	}
    }
	
	public boolean validateUserEmail(String mail){
    	if(Pattern.matches("[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}",mail))
    	{
    	return true;
    	}
    	else
    	{
    		return false;
    	}
    }
	//validateStatus
	
	public boolean validateStatus(String lib){
    	if(Pattern.matches("[Y,N]{1}",lib))
    	{
    	return true;
    	}
    	else
    	{
    		return false;
    	}
    }
	//validateBookId(book_Id)
	public boolean validateBookId(String book_Id){
    	if(Pattern.matches("\\d{4}",book_Id))
    	{
    	return true;
    	}
    	else
    	{
    		return false;
    	}
	}
	
	public boolean validateBookName(String name){
    	if(Pattern.matches("[A-Z][a-z ]{6,15}",name))
    	{
    	return true;
    	}
    	else
    	{
    		return false;
    	}
    }
	public boolean validateAuthor1(String name){
    	if(Pattern.matches("[A-Z][a-z ]{6,15}",name))
    	{
    	return true;
    	}
    	else
    	{
    		return false;
    	}
    }
	public boolean validateAuthor2(String name){
    	if(Pattern.matches("[A-Z][a-z ]{6,15}",name))
    	{
    	return true;
    	}
    	else
    	{
    		return false;
    	}
    }
	//validatePublisher
	public boolean validatePublisher(String name){
    	if(Pattern.matches("[A-Z][a-z ]{6,15}",name))
    	{
    	return true;
    	}
    	else
    	{
    		return false;
    	}
    }
	public boolean validateYOP(String name){
    	if(Pattern.matches("\\d{4}",name))
    	{
    	return true;
    	}
    	else
    	{
    		return false;
    	}
    }
	public boolean validateregistration_Id(String registration_Id){
    	if(Pattern.matches("\\d{4}",registration_Id))
    	{
    	return true;
    	}
    	else
    	{
    		return false;
    	}
	}
	//validateregistration_Id
	
}
