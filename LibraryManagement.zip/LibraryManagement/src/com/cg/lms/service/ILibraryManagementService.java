package com.cg.lms.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.lms.dto.BookInventoryDto;
import com.cg.lms.dto.BookRegistrationDto;
import com.cg.lms.dto.BooksTransactionDto;
import com.cg.lms.dto.UsersDto;
import com.cg.lms.exceptions.LibraryManagementException;

public interface ILibraryManagementService {
	public boolean validateUserId(String userId);
	public boolean validateUserName(String name);
	public UsersDto setValues(UsersDto userDtoObj)throws LibraryManagementException;
	public UsersDto login(UsersDto userDtoObj)throws LibraryManagementException,SQLException;
	public String statusMethod(String idd) throws LibraryManagementException;
	public BookInventoryDto inventory(BookInventoryDto bookIDto) throws LibraryManagementException;
	 public ArrayList<BookInventoryDto> getDisplay()throws LibraryManagementException;
	 public void delRecord(String del) throws LibraryManagementException ;
	 public void delRequest(String del) throws LibraryManagementException;
		public BookRegistrationDto userRequest(BookRegistrationDto regDto) throws LibraryManagementException ;
	    public String getRegistrationId()throws LibraryManagementException, SQLException;

	    public ArrayList<BookRegistrationDto> getRequest()throws LibraryManagementException;
		public BooksTransactionDto transactionMethod(BooksTransactionDto traDto)throws LibraryManagementException,SQLException;
		 public String getTransactionId() throws LibraryManagementException, SQLException;
		 public BooksTransactionDto updateReturn(BooksTransactionDto traDto)throws LibraryManagementException, SQLException;
		 public BooksTransactionDto updateFine(BooksTransactionDto traDto) throws LibraryManagementException, SQLException;
			
			public ArrayList<String> getregId() throws LibraryManagementException;
			public ArrayList<String> gettransId() throws LibraryManagementException;
			public ArrayList<BooksTransactionDto> SearchMobile(String min) throws LibraryManagementException;
			 public ArrayList<String> getbookId() throws LibraryManagementException;
			 public String getBookReg(String idd)throws LibraryManagementException, SQLException;
			 public BookInventoryDto updateAvailability(BookInventoryDto traDto)throws LibraryManagementException, SQLException;
			 public BookRegistrationDto updateStatusReq(BookRegistrationDto s)throws LibraryManagementException, SQLException;
			 public String selectAvailability(String idd)throws LibraryManagementException, SQLException;
			 public String issueStatus1(String idd)throws LibraryManagementException, SQLException;
			 public BookInventoryDto updateAvailabiltyA(BookInventoryDto traDto)throws LibraryManagementException, SQLException;
			 public String getRegTra(String idd)throws LibraryManagementException, SQLException;

			 public String getTidReg(String idd)throws LibraryManagementException, SQLException;
			 public String getRegBId(String idd)throws LibraryManagementException, SQLException;
			 public String delTransaction(String del) throws LibraryManagementException;
			 public ArrayList<String> getBookfromReg() throws LibraryManagementException;
		//	 public String getBookReg(String idd)throws LibraryManagementException, SQLException;
			 public ArrayList<String> getUserId() throws LibraryManagementException;
}