package com.cg.lms.exceptions;

public class LibraryManagementException extends Exception{
public LibraryManagementException(String str) {
	// TODO Auto-generated constructor stub
	super(str);
}
}
