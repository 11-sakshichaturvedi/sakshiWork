package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import com.sun.istack.internal.NotNull;

@Entity
@Table(name="employee_details")

public class EmpDetails {
	@Id
	@Column(name="empid")
	
	private static Long empid;
	
	public static Long getEmpid() {
		return empid;
	}

	public void setEmpid(Long empid) {
		this.empid = empid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Long getTotalleaves() {
		return totalleaves;
	}

	public void setTotalleaves(Long totalleaves) {
		this.totalleaves = totalleaves;
	}

	@Column(name="ename")
	private String name;
	
	@Column(name="address")
	private String address;
	
	@Column(name="leaves_avail")
	private Long totalleaves;
	public EmpDetails(Long empid, String name, String address, Long totalleaves) {
		super();
		this.empid = empid;
		this.name = name;
		this.address = address;
		this.totalleaves = totalleaves;
	}
	public EmpDetails() {
		super();
		
	}

}
