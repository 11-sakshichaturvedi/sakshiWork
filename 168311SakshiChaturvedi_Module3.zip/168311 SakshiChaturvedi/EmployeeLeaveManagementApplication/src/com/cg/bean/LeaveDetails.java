package com.cg.bean;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="employee_leave_details")

public class LeaveDetails {
	@Id
	@Column(name="leave_id")
	private Long lid;
	
	public Long getLid() {
		return lid;
	}

	public void setLid(Long lid) {
		this.lid = lid;
	}

	public Long getEmpid() {
		return empid;
	}

	public void setEmpid(Long empid) {
		this.empid = empid;
	}

	public Date getStartDate() {
		return StartDate;
	}

	public void setStartDate(Date startDate) {
		StartDate = startDate;
	}

	public Date getEndDate() {
		return EndDate;
	}

	public void setEndDate(Date endDate) {
		EndDate = endDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getLeaveNo() {
		return leaveNo;
	}

	public void setLeaveNo(Long leaveNo) {
		this.leaveNo = leaveNo;
	}

	@Column(name="empid")
	private Long empid;
	
	@Column(name="start_date")
	@Temporal(TemporalType.DATE)
	private Date StartDate;
	
	@Column(name="end_date")
	@Temporal(TemporalType.DATE)
	private Date EndDate;
	
	@Column(name="description")
	private String description;

	@Column(name="leaves_applied")
	private Long leaveNo;

	
	

}
