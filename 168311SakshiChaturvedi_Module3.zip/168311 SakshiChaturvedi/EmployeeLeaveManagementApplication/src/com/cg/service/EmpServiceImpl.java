package com.cg.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.EmpDetails;
import com.cg.dao.EmpDao;
import com.cg.exception.EmployeeException;



@Service
@Transactional
public class EmpServiceImpl implements EmpService{
	@Autowired
	EmpDao dao;

	@Override
	public ArrayList<Object> fetchOdDetails(Long empid) throws EmployeeException {
		return dao.fetchOdDetails(empid);
	}
}
