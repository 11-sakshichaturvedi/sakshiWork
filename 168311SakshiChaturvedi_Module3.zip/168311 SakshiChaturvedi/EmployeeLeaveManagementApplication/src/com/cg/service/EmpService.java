package com.cg.service;

import java.util.ArrayList;

import com.cg.exception.EmployeeException;



public interface EmpService {
	public ArrayList<Object> fetchOdDetails(Long empid) throws EmployeeException;
}
