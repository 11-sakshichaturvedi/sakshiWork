package com.cg.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.cg.exception.EmployeeException;



@ControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler (value={EmployeeException.class})
	protected ModelAndView handleConflict(Exception e){
		System.out.println("Caught");
		ModelAndView model = new ModelAndView("ViewLeaveDetails");
		model.addObject("error",e.getMessage());
		return model;
	}
}
