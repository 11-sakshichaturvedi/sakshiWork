package com.cg.controller;

import java.util.ArrayList;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.EmpDetails;
import com.cg.bean.LeaveDetails;

import com.cg.exception.EmployeeException;
import com.cg.service.EmpService;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.validation.BindingResult;
/**
 * Servlet implementation class EmpCtrl
 */
@Controller
@WebServlet("/EmpCtrl")
public class EmpCtrl extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Autowired
	EmpService ser;
	@RequestMapping("/index.obj")
	public String showHomePage(Model model){
		model.addAttribute("EmpDetails",new EmpDetails());
		return "Home";
	}
	@RequestMapping("/employeeView.obj")
	public ModelAndView showDetails(@ModelAttribute("EmpDetails") @Valid EmpDetails employee, BindingResult result) throws EmployeeException {
		ModelAndView modelAndView = new ModelAndView();
		if(!result.hasErrors()){
			
			modelAndView.setViewName("ViewLeaveDetails");
			ArrayList<Object> list = ser.fetchOdDetails(employee.getEmpid());
			EmpDetails employee2 = (EmpDetails) list.get(0);
			@SuppressWarnings("unchecked")
			ArrayList<LeaveDetails> employeeList = (ArrayList<LeaveDetails>) list.get(1);
			if(employeeList.size()==0){
				employeeList= null;
				modelAndView.addObject("err",new String("No Leave Record Found"));
			}
			modelAndView.addObject("EmpDetails", employee2);
			modelAndView.addObject("employeeList",employeeList);
		}else{
			modelAndView.setViewName("Home");
			modelAndView.addObject("employee",employee);
		}
		return modelAndView;
		
	}}