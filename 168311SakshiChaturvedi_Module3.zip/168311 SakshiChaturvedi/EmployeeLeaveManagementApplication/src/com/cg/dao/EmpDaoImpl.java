package com.cg.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.bean.EmpDetails;
import com.cg.bean.LeaveDetails;
import com.cg.exception.EmployeeException;


@Repository
public class EmpDaoImpl implements EmpDao {
	@PersistenceContext
	private EntityManager entitymanager;
	@Override
	public ArrayList<Object> fetchOdDetails(Long empid) throws EmployeeException {
		EmpDetails employee = entitymanager.find(EmpDetails.class, empid);
			
			//throw new EmployeeException("Employee with"+empid+"doesn't exist");
		TypedQuery<LeaveDetails> query = entitymanager.createQuery("SELECT eod FROM LeaveDetails eod WHERE eid = ?",LeaveDetails.class);
		query.setParameter(1, empid);
		ArrayList<LeaveDetails> odList = (ArrayList<LeaveDetails>) query.getResultList();
		ArrayList<Object> list = new ArrayList<Object>();
		list.add(employee);
		list.add(odList);
		return list;
	}
}
