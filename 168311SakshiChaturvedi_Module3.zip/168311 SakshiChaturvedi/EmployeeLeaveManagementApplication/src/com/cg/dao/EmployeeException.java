package com.cg.dao;

public class EmployeeException extends Exception {

}
