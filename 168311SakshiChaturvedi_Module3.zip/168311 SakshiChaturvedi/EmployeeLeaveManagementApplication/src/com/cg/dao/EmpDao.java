package com.cg.dao;

import java.util.ArrayList;

import com.cg.exception.EmployeeException;



public interface EmpDao {
	public ArrayList<Object> fetchOdDetails(Long empid) throws EmployeeException;
}
