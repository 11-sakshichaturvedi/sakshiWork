/**
 * 
 */
package com.cg.hotelBooking.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name ="hoteldetails")
public class hotelDetails {
	@Id
	int id;
	String name;
	String rating;
	double rate;
	int availableRooms;
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the rating
	 */
	public String getRating() {
		return rating;
	}
	/**
	 * @param rating the rating to set
	 */
	public void setRating(String rating) {
		this.rating = rating;
	}
	/**
	 * @return the rate
	 */
	public double getRate() {
		return rate;
	}
	/**
	 * @param rate the rate to set
	 */
	public void setRate(double rate) {
		this.rate = rate;
	}
	/**
	 * @return the availableRooms
	 */
	public int getAvailableRooms() {
		return availableRooms;
	}
	/**
	 * @param availableRooms the availableRooms to set
	 */
	public void setAvailableRooms(int availableRooms) {
		this.availableRooms = availableRooms;
	}
	
	public hotelDetails(int id, String name, String rating, double rate, int availableRooms) {
		super();
		this.id = id;
		this.name = name;
		this.rating = rating;
		this.rate = rate;
		this.availableRooms = availableRooms;
	}
	
	public hotelDetails() {
		super();
	}
	
}
