/**
 * 
 */
package com.cg.hotelBooking.exception;


public class hotelBookingException extends Exception{
	public hotelBookingException(String msg) {
		super(msg);
	}

}
