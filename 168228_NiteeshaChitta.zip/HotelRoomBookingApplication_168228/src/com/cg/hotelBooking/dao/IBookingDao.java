/**
 * 
 */
package com.cg.hotelBooking.dao;

import java.util.List;

import com.cg.hotelBooking.bean.bookingDetails;
import com.cg.hotelBooking.bean.hotelDetails;


public interface IBookingDao {

	List<hotelDetails> getAllHotels();

	void addBooking(bookingDetails tr);

	hotelDetails getHnameBYId(Integer hotelid);

}
