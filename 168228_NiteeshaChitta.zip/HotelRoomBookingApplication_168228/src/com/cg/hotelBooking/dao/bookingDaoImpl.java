/**
 * 
 */
package com.cg.hotelBooking.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.hotelBooking.bean.bookingDetails;
import com.cg.hotelBooking.bean.hotelDetails;



@Repository
public class bookingDaoImpl implements IBookingDao{
	
	@PersistenceContext
	private EntityManager entitymanager;

	@Override
	public List<hotelDetails> getAllHotels() {
		TypedQuery<hotelDetails> query = entitymanager.createQuery("SELECT d FROM hotelDetails d", hotelDetails.class);
		return query.getResultList();
	}

	@Override
	public void addBooking(bookingDetails tr) {
		entitymanager.persist(tr);
		entitymanager.flush();
		
	}

	@Override
	public hotelDetails getHnameBYId(Integer hotelid) {
		
		return entitymanager.find(hotelDetails.class, hotelid);
	}

}
