/**
 * 
 */
package com.cg.hotelBooking.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hotelBooking.bean.bookingDetails;
import com.cg.hotelBooking.bean.hotelDetails;
import com.cg.hotelBooking.dao.IBookingDao;


@Service
@Transactional
public class bookingServiceImpl implements IBookingService{
	
	@Autowired
	IBookingDao bookingDaoObj;

	@Override
	public List<hotelDetails> getAllHotels() {
		return bookingDaoObj.getAllHotels();
	}

	@Override
	public void addBooking(bookingDetails tr) { 
		bookingDaoObj.addBooking(tr);
	}
	
	

	@Override
	public hotelDetails getHnameBYId(Integer hotelid) {
		return bookingDaoObj.getHnameBYId(hotelid);
	}

}
