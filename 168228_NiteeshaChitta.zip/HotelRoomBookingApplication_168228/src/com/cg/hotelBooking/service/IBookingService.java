/**
 * 
 */
package com.cg.hotelBooking.service;

import java.util.List;

import com.cg.hotelBooking.bean.bookingDetails;
import com.cg.hotelBooking.bean.hotelDetails;


public interface IBookingService {

	List<hotelDetails> getAllHotels();

	void addBooking(bookingDetails tr);

	hotelDetails getHnameBYId(Integer hotelid);

	

}
