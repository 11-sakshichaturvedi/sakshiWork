/**
 * 
 */
package com.cg.hotelBooking.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.cg.hotelBooking.bean.bookingDetails;
import com.cg.hotelBooking.bean.hotelDetails;
import com.cg.hotelBooking.service.IBookingService;


@Controller
public class bookingController {
	@Autowired
	IBookingService bookingServiceObj;
	
	
	
	@RequestMapping("/hotelDetails")
	public String all(Model m) {

		List<hotelDetails> hotelsList = bookingServiceObj.getAllHotels();
		if (!hotelsList.isEmpty()) {
			m.addAttribute("hotels", hotelsList);
			//return "allHotels";
			return "HotelDetails";
		} else {
			m.addAttribute("msg", "Empty Records");
			m.addAttribute("go", "index.jsp");
			return "error";
		}

	}
	
	
	@RequestMapping(value="/booking" ,method=RequestMethod.POST)
	public String saveTrainee(Integer userid, String cname, Integer hotelid, Date todate, Date fromdate, Integer rooms,Model m) {
		bookingDetails tr=new bookingDetails(userid, cname, hotelid, todate,fromdate,rooms);
		hotelDetails hd = bookingServiceObj.getHnameBYId(hotelid);
		 bookingServiceObj.addBooking(tr);
		m.addAttribute("hname",hd.getName());
		return "BookingConfirmation";
	}
	 
	
	
	
	
	
}
